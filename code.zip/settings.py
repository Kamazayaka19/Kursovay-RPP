"""
Настройки проекта «Электронная очередь студенческого МФЦ».

Секреты и параметры окружения берутся из переменных окружения
(см. .env.example) — в исходном коде паролей нет (требование управления ИТ).
Правила приоритета очереди собраны в словаре QUEUE ниже — не в коде логики.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def env_bool(name, default=False):
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in ("1", "true", "yes", "on")


SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "dev-only-insecure-key-change-me")
DEBUG = env_bool("DJANGO_DEBUG", True)

_hosts = os.environ.get("DJANGO_ALLOWED_HOSTS", "*" if DEBUG else "localhost,127.0.0.1")
ALLOWED_HOSTS = [h.strip() for h in _hosts.split(",") if h.strip()]
CSRF_TRUSTED_ORIGINS = [
    o.strip() for o in os.environ.get("DJANGO_CSRF_TRUSTED_ORIGINS", "").split(",") if o.strip()
]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "queueapp",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

# WhiteNoise нужен только для боевого запуска (DEBUG=False, Docker).
try:
    import whitenoise  # noqa: F401
    MIDDLEWARE.insert(1, "whitenoise.middleware.WhiteNoiseMiddleware")
except ImportError:
    pass

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "queueapp.context_processors.mfc",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"

# SQLite — единственный источник истины, состояние переживает рестарт.
# transaction_mode=IMMEDIATE: каждая транзакция сразу берёт блокировку записи,
# поэтому два окна физически не могут одновременно забрать один талон
# (работает и между несколькими процессами, не только потоками).
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": os.environ.get("DJANGO_DB_PATH", str(BASE_DIR / "db.sqlite3")),
        "OPTIONS": {
            "timeout": 20,
            "transaction_mode": "IMMEDIATE",
            "init_command": "PRAGMA journal_mode=WAL;",
        },
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
]

LANGUAGE_CODE = "ru"
TIME_ZONE = "Europe/Moscow"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

LOGIN_URL = "login"
LOGIN_REDIRECT_URL = "staff_home"
LOGOUT_REDIRECT_URL = "home"

SESSION_COOKIE_AGE = 60 * 60 * 24 * 14  # талон в сессии живёт 2 недели

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {"plain": {"format": "%(asctime)s %(levelname)s %(name)s %(message)s"}},
    "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "plain"}},
    "loggers": {"queueapp": {"handlers": ["console"], "level": "INFO"}},
}

# ---------------------------------------------------------------------------
# Параметры МФЦ
# ---------------------------------------------------------------------------

# Личный кабинет студента (1С:Университет ПРОФ).
LK_URL = os.environ.get("MFC_LK_URL", "https://lk.rgau-msha.ru")

# Секрет в ссылке QR-таблички на стойке. Кто открыл эту ссылку — находится в МФЦ
# и может встать в живую очередь. Поменяйте перед пилотом.
QR_SECRET = os.environ.get("MFC_QR_SECRET", "mfc-stand-demo")

QUEUE = {
    # Базовый вес источника талона: меньше = выше приоритет.
    "SOURCE_WEIGHT": {"booking": 0, "qr": 10, "walkin": 10},
    # На сколько улучшается score за каждую минуту ожидания (защита от «голодания»).
    "AGING_RATE_PER_MIN": 0.5,
    # Окно явки по записи: время слота ± GRACE_MINUTES.
    "GRACE_MINUTES": 10,
    # Бонус приоритета записи внутри окна явки.
    "BOOKING_BONUS": 100,
    # За сколько минут до слота можно отметиться «Я на месте».
    "CHECKIN_EARLY_MINUTES": 30,
    # Расписание слотов записи.
    "SLOT_MINUTES": 15,
    "WORK_DAYS": [0, 1, 2, 3, 4],  # пн–пт
    "WORK_START": "09:30",  # часы приёма МФЦ с сайта timacad.ru
    "WORK_END": "17:30",
    "LUNCH": None,  # например ("13:00", "14:00"), если появится перерыв
    "BOOKING_DAYS_AHEAD": 10,
    # Уведомить клиента, когда перед ним осталось столько человек.
    "NOTIFY_AHEAD": 3,
}

# Контакты МФЦ для подвала сайта (timacad.ru/students/studencheskii-mfts).
MFC_CONTACTS = {
    "address_ru": "г. Москва, Лиственничная аллея, 2А",
    "address_en": "2A Listvennichnaya Alley, Moscow",
    "map_url": "https://yandex.ru/maps/org/mskha_imeni_k_a_timiryazeva_studencheskiy_mfts/8136079545/",
    "phone": "+7 (499) 977-14-33",
    "email": "mfts@rgau-msha.ru",
    "hours": "09:30–17:30",
    "site_url": "https://www.timacad.ru/students/studencheskii-mfts",
}

# Логотип вуза: положите файл в queueapp/static/queueapp/ (logo.svg или logo.png).
# Если файла нет, вместо логотипа выводится название университета текстом.
MFC_LOGO_CANDIDATES = ["queueapp/logo.svg", "queueapp/logo.png"]
