"""
Показатели пилота (паспорт проекта, раздел 10). Аналитика строится по окнам,
услугам и часам — без персонального рейтинга сотрудников (ПР №3, сторона №5).
"""
from collections import defaultdict
from datetime import timedelta

from django.conf import settings
from django.utils import timezone

from .models import EventLog, Service, Ticket, Window
from .engine import _hm


def _minutes(a, b):
    return (b - a).total_seconds() / 60


def _avg(values):
    return round(sum(values) / len(values), 1) if values else None


def _share(part, whole):
    return round(100 * part / whole) if whole else None


def period_start(days):
    return timezone.localdate() - timedelta(days=days - 1)


def build(days=1):
    cfg = settings.QUEUE
    grace = timedelta(minutes=cfg["GRACE_MINUTES"])
    start_day = period_start(days)

    tickets = list(Ticket.objects.filter(day__gte=start_day).select_related("service", "window"))
    completed = [t for t in tickets if t.status == Ticket.COMPLETED]

    # Ожидание считаем по электронным талонам; клиенты «без талона» вызваны сразу.
    def wait_of(t):
        if t.called_at and t.entered_queue_at and t.source != "walkin":
            return max(0.0, _minutes(t.entered_queue_at, t.called_at))
        return None

    waits = [w for w in (wait_of(t) for t in completed) if w is not None]

    bookings = [t for t in tickets if t.source == "booking" and t.status != Ticket.CANCELLED]
    came = [t for t in bookings if t.called_at]
    in_slot = [t for t in came if t.called_at <= t.slot_start + grace]
    booking_no_show = [t for t in bookings if t.status == Ticket.NO_SHOW]

    lk_clicks = EventLog.objects.filter(event="lk_redirect", ts__date__gte=start_day).count()
    issues = EventLog.objects.filter(event="issue_reported", ts__date__gte=start_day).count()
    requests_total = len([t for t in tickets if t.status != Ticket.CANCELLED])

    by_source = defaultdict(int)
    for t in tickets:
        if t.status != Ticket.CANCELLED:
            by_source[t.source] += 1

    # Загрузка по часам: сколько человек встали в очередь и сколько ждали.
    h_from, _ = _hm(cfg["WORK_START"])
    h_to, m_to = _hm(cfg["WORK_END"])
    last_hour = h_to if m_to else h_to - 1
    hours = {h: {"hour": h, "arrived": 0, "waits": []} for h in range(h_from, last_hour + 1)}
    for t in tickets:
        if not t.entered_queue_at:
            continue
        h = timezone.localtime(t.entered_queue_at).hour
        row = hours.setdefault(h, {"hour": h, "arrived": 0, "waits": []})
        row["arrived"] += 1
        w = wait_of(t)
        if w is not None:
            row["waits"].append(w)
    hour_rows = [hours[h] for h in sorted(hours)]
    peak = max((r["arrived"] for r in hour_rows), default=0) or 1
    for r in hour_rows:
        r["avg_wait"] = _avg(r["waits"])
        r["pct"] = round(100 * r["arrived"] / peak)
        r["label"] = f"{r['hour']:02d}:00"

    # По услугам
    service_rows = []
    for s in Service.objects.all():
        st = [t for t in tickets if t.service_id == s.pk and t.status != Ticket.CANCELLED]
        if not st and not s.is_active:
            continue
        done = [t for t in st if t.status == Ticket.COMPLETED]
        dur = [_minutes(t.serving_at, t.completed_at) for t in done if t.serving_at and t.completed_at]
        lk = EventLog.objects.filter(event="lk_redirect", service=s, ts__date__gte=start_day).count()
        service_rows.append({
            "service": s,
            "total": len(st),
            "completed": len(done),
            "avg_wait": _avg([w for w in (wait_of(t) for t in done) if w is not None]),
            "avg_duration": _avg(dur),
            "norm": s.avg_time_min,
            "lk": lk,
        })

    # По окнам (не по сотрудникам)
    window_rows = []
    for w in Window.objects.prefetch_related("services").select_related("current_ticket"):
        done = [t for t in completed if t.window_id == w.pk]
        dur = [_minutes(t.serving_at, t.completed_at) for t in done if t.serving_at and t.completed_at]
        window_rows.append({
            "window": w,
            "completed": len(done),
            "avg_duration": _avg(dur),
            "services": ", ".join(s.code for s in w.services.all()) or "—",
        })

    return {
        "days": days,
        "start_day": start_day,
        "requests_total": requests_total,
        "served": len(completed),
        "avg_wait": _avg(waits),
        "max_wait": round(max(waits), 1) if waits else None,
        "in_slot_share": _share(len(in_slot), len(came)),
        "in_slot_n": len(in_slot),
        "came_n": len(came),
        "no_show_n": len(booking_no_show),
        "no_show_share": _share(len(booking_no_show), len(bookings)),
        "lk_clicks": lk_clicks,
        "lk_share": _share(lk_clicks, lk_clicks + requests_total),
        "walkin_share": _share(by_source["walkin"], requests_total),
        "by_source": dict(by_source),
        "issues": issues,
        "hours": hour_rows,
        "services": service_rows,
        "windows": window_rows,
    }


EXPORT_HEADER = ["Талон", "День", "Услуга", "Канал", "Статус", "Слот", "Встал в очередь",
                 "Вызван", "Начало приёма", "Завершён", "Окно", "Перенаправлений"]


def export_rows(days):
    """Строки CSV-выгрузки (с заголовком) — общие для веба и десктопа."""
    start = period_start(max(1, min(days, 365)))

    def f(dt):
        return timezone.localtime(dt).strftime("%Y-%m-%d %H:%M:%S") if dt else ""

    rows = [EXPORT_HEADER]
    qs = Ticket.objects.filter(day__gte=start).select_related("service", "window").order_by("created_at")
    for t in qs:
        rows.append([t.number, t.day.isoformat(), t.service.name, t.get_source_display(), t.get_status_display(),
                     f(t.slot_start), f(t.entered_queue_at), f(t.called_at), f(t.serving_at), f(t.completed_at),
                     t.window.number if t.window else "", t.redirect_count])
    return start, rows
