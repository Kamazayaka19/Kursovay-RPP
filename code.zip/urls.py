from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("service/<int:pk>/", views.service_detail, name="service"),
    path("service/<int:pk>/book/", views.book, name="book"),
    path("service/<int:pk>/live/", views.take_live, name="take_live"),
    path("service/<int:pk>/lk/", views.go_lk, name="go_lk"),
    path("t/<str:token>/", views.ticket_view, name="ticket"),
    path("t/<str:token>/checkin/", views.ticket_checkin, name="ticket_checkin"),
    path("t/<str:token>/cancel/", views.ticket_cancel, name="ticket_cancel"),
    path("my/", views.my_ticket, name="my_ticket"),
    path("board/", views.board, name="board"),
    path("qr/", views.qr_stand, name="qr_stand"),
    path("qr/<str:key>/", views.qr_enter, name="qr_enter"),
    path("staff/", views.staff_home, name="staff_home"),
    path("operator/", views.operator_home, name="operator_home"),
    path("operator/<int:pk>/", views.operator_window, name="operator_window"),
    path("operator/<int:pk>/action/", views.operator_action, name="operator_action"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("dashboard/export.csv", views.export_csv, name="export_csv"),
    path("api/ticket/<str:token>/", views.api_ticket, name="api_ticket"),
    path("api/queue/", views.api_queue, name="api_queue"),
    path("api/services/", views.api_services, name="api_services"),
    path("api/services/<int:pk>/slots/", views.api_slots, name="api_slots"),
    path("api/services/<int:pk>/live/", views.api_take_live, name="api_take_live"),
    path("api/services/<int:pk>/book/", views.api_book, name="api_book"),
    path("api/ticket/<str:token>/<str:action>/", views.api_ticket_action, name="api_ticket_action"),
    path("lang/<str:code>/", views.set_lang, name="set_lang"),
    path("a11y/", views.toggle_a11y, name="toggle_a11y"),
    path("health/", views.health, name="health"),
]
