from django.contrib import admin
from django.urls import include, path

admin.site.site_header = "Электронная очередь МФЦ — администрирование"
admin.site.site_title = "МФЦ: администрирование"
admin.site.index_title = "Справочник услуг, окна, пользователи и журнал"

urlpatterns = [
    path("admin/", admin.site.urls),
    path("accounts/", include("django.contrib.auth.urls")),
    path("", include("queueapp.urls")),
]
