"""
Ядро очереди — единственное место, где решается, кого вызвать следующим.

Перенесено из Streamlit-прототипа (queue_engine.py) на ORM Django:
* threading.Lock заменён транзакцией SQLite в режиме IMMEDIATE + условным
  UPDATE ... WHERE status='waiting' — защита от двойного назначения
  работает даже при нескольких процессах сервера;
* коэффициенты приоритета — в settings.QUEUE;
* добавлены запись на слот с отметкой «Я на месте», «не явился» у окна
  и приём клиента без талона (резервный режим с бумажными талонами).
"""
import logging
import math
import time
from datetime import datetime, timedelta

from django.conf import settings
from django.db import transaction
from django.db.models import Count
from django.utils import timezone

from .models import EventLog, Service, Ticket, Window

log_ = logging.getLogger("queueapp")
CFG = settings.QUEUE


class QueueError(Exception):
    """code — ключ строки в i18n.py, понятный пользователю."""

    def __init__(self, code):
        super().__init__(code)
        self.code = code


def log(event, ticket=None, window=None, service=None, payload="", actor="system"):
    EventLog.objects.create(
        event=event, ticket=ticket, window=window,
        service=service or (ticket.service if ticket else None),
        payload=payload[:300], actor=actor[:60],
    )
    log_.info("event=%s ticket=%s window=%s %s", event, ticket, window, payload)


def _hm(value):
    h, m = value.split(":")
    return int(h), int(m)


def _aware(day, hm):
    return timezone.make_aware(datetime(day.year, day.month, day.day, *hm))


# ---------------------------------------------------------------------------
# Номера и создание талонов
# ---------------------------------------------------------------------------

def _next_number(service, day):
    n = Ticket.objects.filter(service=service, day=day).count() + 1
    return f"{service.code}-{n:03d}"


def create_live_ticket(service, actor="client"):
    """Талон в живую очередь (клиент отсканировал QR в МФЦ)."""
    with transaction.atomic():
        now = timezone.now()
        day = timezone.localdate()
        ticket = Ticket.objects.create(
            number=_next_number(service, day), day=day, service=service,
            source="qr", status=Ticket.WAITING, created_at=now, entered_queue_at=now,
        )
        log("created", ticket, payload="source=qr", actor=actor)
    return ticket


def booking_days():
    """Рабочие дни, на которые открыта запись (включая сегодня)."""
    today = timezone.localdate()
    days = []
    for i in range(CFG["BOOKING_DAYS_AHEAD"] + 7):
        d = today + timedelta(days=i)
        if d.weekday() in CFG["WORK_DAYS"]:
            days.append(d)
        if len(days) >= CFG["BOOKING_DAYS_AHEAD"]:
            break
    return days


def slots_for(service, day):
    """Список (начало слота, свободно мест). Прошедшие слоты не показываются."""
    if day.weekday() not in CFG["WORK_DAYS"]:
        return []
    step = timedelta(minutes=CFG["SLOT_MINUTES"])
    start = _aware(day, _hm(CFG["WORK_START"]))
    end = _aware(day, _hm(CFG["WORK_END"]))
    lunch = CFG.get("LUNCH")
    lunch_from = _aware(day, _hm(lunch[0])) if lunch else None
    lunch_to = _aware(day, _hm(lunch[1])) if lunch else None

    taken = dict(
        Ticket.objects.filter(service=service, day=day, source="booking")
        .exclude(status=Ticket.CANCELLED)
        .order_by()
        .values_list("slot_start")
        .annotate(c=Count("id"))
    )
    now = timezone.now()
    result = []
    current = start
    while current + step <= end:
        in_lunch = lunch_from and lunch_from <= current < lunch_to
        if not in_lunch and current > now:
            free = service.slot_capacity - taken.get(current, 0)
            result.append((current, max(0, free)))
        current += step
    return result


def create_booking(service, slot_start, actor="client"):
    if not service.booking_enabled:
        raise QueueError("err_booking_disabled")
    with transaction.atomic():
        day = timezone.localdate(slot_start)
        valid = {s for s, free in slots_for(service, day) if free > 0}
        if slot_start not in valid:
            raise QueueError("err_slot_full")
        ticket = Ticket.objects.create(
            number=_next_number(service, day), day=day, service=service,
            source="booking", status=Ticket.BOOKED, slot_start=slot_start,
        )
        log("created", ticket, payload=f"source=booking slot={timezone.localtime(slot_start):%Y-%m-%d %H:%M}",
            actor=actor)
    return ticket


def checkin_window(ticket):
    early = timedelta(minutes=CFG["CHECKIN_EARLY_MINUTES"])
    grace = timedelta(minutes=CFG["GRACE_MINUTES"])
    return ticket.slot_start - early, ticket.slot_start + grace


def check_in(ticket):
    """Клиент по записи пришёл: «Я на месте» → встаёт в очередь с бонусом записи."""
    if ticket.status != Ticket.BOOKED:
        raise QueueError("err_not_booked")
    opens, closes = checkin_window(ticket)
    now = timezone.now()
    if now < opens:
        raise QueueError("err_checkin_early")
    if now > closes:
        raise QueueError("err_checkin_late")
    with transaction.atomic():
        updated = Ticket.objects.filter(pk=ticket.pk, status=Ticket.BOOKED).update(
            status=Ticket.WAITING, entered_queue_at=now
        )
        if updated:
            log("checked_in", ticket, actor="client")


def cancel(ticket):
    with transaction.atomic():
        updated = Ticket.objects.filter(pk=ticket.pk, status__in=[Ticket.BOOKED, Ticket.WAITING]).update(
            status=Ticket.CANCELLED
        )
        if not updated:
            raise QueueError("err_cannot_cancel")
        log("cancelled", ticket, actor="client")


# ---------------------------------------------------------------------------
# Фоновая «уборка»: сгоревшие записи и талоны прошлых дней
# ---------------------------------------------------------------------------

_last_sweep = 0.0


def sweep(force=False):
    global _last_sweep
    if not force and time.monotonic() - _last_sweep < 20:
        return
    _last_sweep = time.monotonic()
    now = timezone.now()
    grace = timedelta(minutes=CFG["GRACE_MINUTES"])
    with transaction.atomic():
        for t in Ticket.objects.filter(status=Ticket.BOOKED, slot_start__lt=now - grace).select_related("service"):
            Ticket.objects.filter(pk=t.pk, status=Ticket.BOOKED).update(status=Ticket.NO_SHOW)
            log("no_show_booking", t, payload="slot expired, no check-in")
        stale = Ticket.objects.filter(
            status__in=[Ticket.WAITING, Ticket.CALLED, Ticket.SERVING], day__lt=timezone.localdate()
        )
        for t in stale.select_related("service"):
            Ticket.objects.filter(pk=t.pk).update(status=Ticket.CANCELLED)
            log("expired_end_of_day", t)
        Window.objects.filter(current_ticket__status__in=[Ticket.CANCELLED, Ticket.NO_SHOW,
                                                          Ticket.COMPLETED]).update(current_ticket=None)


# ---------------------------------------------------------------------------
# Приоритет и позиция в очереди
# ---------------------------------------------------------------------------

def priority_score(t, now):
    weight = CFG["SOURCE_WEIGHT"].get(t.source, 10)
    entered = t.entered_queue_at or t.created_at
    waited = max(0.0, (now - entered).total_seconds() / 60)
    score = weight - CFG["AGING_RATE_PER_MIN"] * waited
    if t.source == "booking" and t.slot_start:
        grace = timedelta(minutes=CFG["GRACE_MINUTES"])
        if t.slot_start - grace <= now <= t.slot_start + grace:
            score -= CFG["BOOKING_BONUS"]
    return score


def ordered_waiting(service_ids=None):
    qs = Ticket.objects.filter(status=Ticket.WAITING).select_related("service")
    if service_ids is not None:
        qs = qs.filter(service_id__in=service_ids)
    now = timezone.now()
    rows = list(qs)
    rows.sort(key=lambda t: (priority_score(t, now), t.entered_queue_at or t.created_at))
    return rows


def open_windows_for(service):
    return Window.objects.filter(status=Window.STATUS_OPEN, services=service).count()


def position(ticket):
    if ticket.status != Ticket.WAITING:
        return None
    for i, t in enumerate(ordered_waiting([ticket.service_id])):
        if t.pk == ticket.pk:
            return i + 1
    return None


def estimate_wait(service, people_ahead):
    """Прогноз ожидания в минутах; None — нет открытых окон с этой услугой."""
    windows = open_windows_for(service)
    if windows == 0:
        return None
    return math.ceil(people_ahead * service.avg_time_min / windows)


# ---------------------------------------------------------------------------
# Окна
# ---------------------------------------------------------------------------

def open_window(window, service_ids, actor):
    if not service_ids:
        raise QueueError("err_choose_services")
    with transaction.atomic():
        window.services.set(Service.objects.filter(pk__in=service_ids))
        Window.objects.filter(pk=window.pk).update(status=Window.STATUS_OPEN)
        log("window_opened", window=window, payload=f"services={','.join(map(str, service_ids))}", actor=actor)


def close_window(window, force, actor):
    """Мягко: текущего клиента дообслужить, новых не вызывать.
    Немедленно: текущий талон возвращается в очередь с исходным временем."""
    with transaction.atomic():
        w = Window.objects.select_related("current_ticket").get(pk=window.pk)
        active = w.current_ticket if w.current_ticket and w.current_ticket.status in (
            Ticket.CALLED, Ticket.SERVING) else None
        if active and not force:
            Window.objects.filter(pk=w.pk).update(status=Window.STATUS_CLOSING)
            log("window_closing_soft", active, window=w, actor=actor)
            return
        if active:
            Ticket.objects.filter(pk=active.pk).update(status=Ticket.WAITING, window=None, called_at=None)
            log("requeued_window_force_closed", active, window=w, actor=actor)
        Window.objects.filter(pk=w.pk).update(status=Window.STATUS_CLOSED, current_ticket=None)
        log("window_closed", window=w, actor=actor)


def _release(window_id):
    w = Window.objects.get(pk=window_id)
    new_status = Window.STATUS_CLOSED if w.status == Window.STATUS_CLOSING else w.status
    Window.objects.filter(pk=window_id).update(current_ticket=None, status=new_status)


def _current(window_id, statuses):
    w = Window.objects.select_related("current_ticket").get(pk=window_id)
    t = w.current_ticket
    if not t or t.status not in statuses:
        raise QueueError("err_no_current")
    return w, t


# ---------------------------------------------------------------------------
# Диспетчеризация
# ---------------------------------------------------------------------------

def call_next(window, actor):
    """Атомарно выбирает талон с наименьшим score среди услуг окна."""
    with transaction.atomic():
        w = Window.objects.get(pk=window.pk)
        if w.status != Window.STATUS_OPEN:
            raise QueueError("err_window_not_open")
        if w.current_ticket_id:
            raise QueueError("err_window_busy")
        allowed = list(w.services.values_list("id", flat=True))
        if not allowed:
            raise QueueError("err_choose_services")
        for candidate in ordered_waiting(allowed):
            now = timezone.now()
            updated = Ticket.objects.filter(pk=candidate.pk, status=Ticket.WAITING).update(
                status=Ticket.CALLED, window=w, called_at=now
            )
            if not updated:
                continue  # талон перехватили — берём следующего
            bound = Window.objects.filter(pk=w.pk, current_ticket__isnull=True).update(current_ticket=candidate)
            if not bound:
                raise QueueError("err_window_busy")  # откат всей транзакции
            log("called", candidate, window=w, actor=actor)
            return Ticket.objects.get(pk=candidate.pk)
    return None


def start_serving(window, actor):
    with transaction.atomic():
        w, t = _current(window.pk, [Ticket.CALLED])
        Ticket.objects.filter(pk=t.pk, status=Ticket.CALLED).update(status=Ticket.SERVING, serving_at=timezone.now())
        log("serving_started", t, window=w, actor=actor)


def complete(window, actor):
    with transaction.atomic():
        w, t = _current(window.pk, [Ticket.CALLED, Ticket.SERVING])
        now = timezone.now()
        Ticket.objects.filter(pk=t.pk).update(
            status=Ticket.COMPLETED, completed_at=now, serving_at=t.serving_at or t.called_at
        )
        _release(w.pk)
        log("completed", t, window=w, actor=actor)


def recall(window, actor):
    with transaction.atomic():
        w, t = _current(window.pk, [Ticket.CALLED])
        log("recalled", t, window=w, actor=actor)


def mark_no_show(window, actor):
    with transaction.atomic():
        w, t = _current(window.pk, [Ticket.CALLED])
        Ticket.objects.filter(pk=t.pk).update(status=Ticket.NO_SHOW)
        _release(w.pk)
        log("no_show_at_window", t, window=w, actor=actor)


def return_to_queue(window, actor):
    with transaction.atomic():
        w, t = _current(window.pk, [Ticket.CALLED, Ticket.SERVING])
        Ticket.objects.filter(pk=t.pk).update(status=Ticket.WAITING, window=None, called_at=None, serving_at=None)
        _release(w.pk)
        log("returned_to_queue", t, window=w, actor=actor)


def redirect(window, new_service, actor):
    with transaction.atomic():
        w, t = _current(window.pk, [Ticket.CALLED, Ticket.SERVING])
        Ticket.objects.filter(pk=t.pk).update(
            status=Ticket.WAITING, service=new_service, window=None, called_at=None, serving_at=None,
            redirect_count=t.redirect_count + 1,
        )
        _release(w.pk)
        log("redirected", t, window=w, service=new_service, payload=f"from={t.service.code} to={new_service.code}",
            actor=actor)


def add_walkin(window, service, actor):
    """Клиент без электронного талона (бумажный талон / пришёл без телефона):
    оператор сразу принимает его через систему — так обращение попадёт в статистику."""
    with transaction.atomic():
        w = Window.objects.get(pk=window.pk)
        if w.status != Window.STATUS_OPEN:
            raise QueueError("err_window_not_open")
        if w.current_ticket_id:
            raise QueueError("err_window_busy")
        now = timezone.now()
        day = timezone.localdate()
        t = Ticket.objects.create(
            number=_next_number(service, day), day=day, service=service, source="walkin",
            status=Ticket.CALLED, created_at=now, entered_queue_at=now, called_at=now, window=w,
        )
        Window.objects.filter(pk=w.pk).update(current_ticket=t)
        log("walkin_added", t, window=w, actor=actor)
        return t


def report_issue(window, note, actor):
    w = Window.objects.select_related("current_ticket").get(pk=window.pk)
    log("issue_reported", w.current_ticket, window=w, payload=note, actor=actor)
