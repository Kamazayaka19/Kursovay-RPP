"""Роли сотрудников — группы Django. Доступ разграничен, общего пароля нет."""
from functools import wraps

from django.contrib.auth.views import redirect_to_login
from django.shortcuts import render

OPERATOR = "Оператор"
ADMIN = "Администратор"
MANAGER = "Руководитель"


def has_role(user, *groups):
    if not user.is_authenticated:
        return False
    if user.is_superuser:
        return True
    return user.groups.filter(name__in=groups).exists()


def role_required(*groups):
    def decorator(view):
        @wraps(view)
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect_to_login(request.get_full_path())
            if not has_role(request.user, *groups):
                return render(request, "queueapp/forbidden.html", status=403)
            return view(request, *args, **kwargs)
        return wrapper
    return decorator
