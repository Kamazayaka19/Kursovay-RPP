"""
Самопроверка десктоп-версии на временной базе (рабочая db.sqlite3 не трогается).

    python desktop/test_desktop.py [папка_для_скриншотов]

1) сценарий через Backend: талон → открыть окно → вызвать → принять → завершить, запись на слот, CSV;
2) загрузка всех QML-экранов без окна (offscreen) — любая ошибка QML роняет тест.
"""
import os
import sys
import tempfile
from pathlib import Path

tmp = tempfile.mkdtemp()
os.environ["DJANGO_DB_PATH"] = os.path.join(tmp, "test.sqlite3")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
shots = Path(sys.argv[1]) if len(sys.argv) > 1 else None

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import desktop.main as m  # noqa: E402  (настраивает Django)

from PySide6.QtCore import QUrl, QtMsgType, qInstallMessageHandler  # noqa: E402
from PySide6.QtGui import QGuiApplication  # noqa: E402
from PySide6.QtQml import QQmlApplicationEngine  # noqa: E402

import shiboken6  # noqa: E402
from PySide6.QtQuick import QQuickWindow  # noqa: E402

from desktop.backend import Backend  # noqa: E402

m.prepare_db()
b = Backend()

# ---- 1. Сценарий
svc = next(s for s in b.services() if s["booking"])
t = b.takeLive(svc["id"])
assert t["status"] == "waiting" and t["ahead"] == 0, t
assert b.windowState(1) == {}, "без входа оператору ничего не видно"
assert not b.login("operator1", "wrong")
assert b.login("operator1", "demo12345") and b.isOperator and not b.isManager

win = b.windows()[0]["id"]
assert b.operatorAction(win, "call_next", None) != "", "закрытое окно не вызывает"
assert b.operatorAction(win, "open", [svc["id"]]) == ""
assert b.operatorAction(win, "call_next", None) == ""
assert b.findTicket(t["number"])["window"] == b.windowState(win)["number"]
assert b.operatorAction(win, "start", None) == ""
assert b.operatorAction(win, "complete", None) == ""
assert b.findTicket(t["number"])["status"] == "completed"
assert b.operatorAction(win, "call_next", None) == "Очередь пуста."
assert b.operatorAction(win, "issue", "нет бланков") == "Записано в журнал событий."

days = b.bookingDays(svc["id"])
if days:  # вечером/в выходной свободных слотов может не быть
    slot = next(s for s in b.slots(svc["id"], days[0]["iso"]) if s["free"])
    booked = b.book(svc["id"], slot["iso"])
    assert booked["status"] == "booked" and booked["canCheckIn"], booked
    assert b.cancel(booked["token"])["status"] == "cancelled"

assert b.dashboard(1) == {}, "оператор не видит дашборд"
b.logout()
assert b.login("manager", "demo12345") and b.isManager
assert len(b.dashboard(28)["kpi"]) == 8
csv_path = os.path.join(tmp, "out.csv")
assert b.exportCsv(28, QUrl.fromLocalFile(csv_path)).startswith("Сохранено")
assert open(csv_path, encoding="utf-8-sig").readline().startswith("Талон;")
b.logout()
print("backend: ok")

# ---- 2. QML
errors = []


def handler(mode, _ctx, msg):
    if mode != QtMsgType.QtDebugMsg:
        errors.append(msg)


qInstallMessageHandler(handler)
app = QGuiApplication([])
engine = QQmlApplicationEngine()
engine.rootContext().setContextProperty("backend", b)
engine.load(Path(m.__file__).parent / "qml" / "Main.qml")
assert engine.rootObjects(), errors
window = engine.rootObjects()[0]
quick = shiboken6.wrapInstance(shiboken6.getCppPointer(window)[0], QQuickWindow)


def pump():
    for _ in range(20):
        app.processEvents()


b.login("mfcadmin", "demo12345")  # администратор видит все 4 вкладки
b.takeLive(svc["id"])
pump()
for i, name in enumerate(["client", "board", "operator", "dashboard"]):
    window.setProperty("tabIndex", i)
    window.setProperty("tick", window.property("tick") + 1)
    pump()
    print("tab", name, flush=True)
    if shots:
        shots.mkdir(parents=True, exist_ok=True)
        quick.grabWindow().save(str(shots / f"{name}.png"))

assert not errors, "\n".join(errors)
print("qml: ok")
