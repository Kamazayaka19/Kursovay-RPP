"""
Мост между QML-интерфейсом и ядром очереди.

Вся логика (приоритет, атомарный вызов, запись на слот, аналитика) — та же,
что в веб-версии: queueapp/engine.py и queueapp/analytics.py используются без изменений.
Здесь только перевод Python-объектов в списки/словари, понятные QML.
"""
import csv
from datetime import date, datetime, timedelta

from django.contrib.auth import authenticate
from django.utils import timezone
from PySide6.QtCore import QObject, QUrl, Signal, Slot, Property

from queueapp import analytics, engine, roles, views
from queueapp.i18n import fmt_day, tr
from queueapp.models import EventLog, Service, Ticket, Window

LANG = "ru"


def _hm(dt):
    return timezone.localtime(dt).strftime("%H:%M") if dt else ""


def _err(exc):
    return tr(exc.code, LANG)


class Backend(QObject):
    userChanged = Signal()

    def __init__(self):
        super().__init__()
        self._user = None

    # ------------------------------------------------------------------ вход
    def _role(self, *groups):
        return bool(self._user) and roles.has_role(self._user, *groups)

    @Property(str, notify=userChanged)
    def userName(self):
        return self._user.get_username() if self._user else ""

    @Property(bool, notify=userChanged)
    def isOperator(self):
        return self._role(roles.OPERATOR, roles.ADMIN)

    @Property(bool, notify=userChanged)
    def isManager(self):
        return self._role(roles.MANAGER, roles.ADMIN)

    @Slot(str, str, result=bool)
    def login(self, username, password):
        user = authenticate(username=username.strip(), password=password)
        self._user = user if user and user.is_active else None
        self.userChanged.emit()
        return self._user is not None

    @Slot()
    def logout(self):
        self._user = None
        self.userChanged.emit()

    # ---------------------------------------------------------- клиент
    @Slot(result="QVariantList")
    def services(self):
        engine.sweep()
        waiting, open_counts = views._queue_snapshot()
        cats = dict(Service.CATEGORY_CHOICES)
        rows = []
        for s in Service.objects.filter(is_active=True):
            n, wait = views._wait_for(s, waiting, open_counts)
            rows.append({
                "id": s.pk, "code": s.code, "name": s.name, "category": cats.get(s.category, "Другое"),
                "waiting": n, "wait": -1 if wait is None else wait,
                "description": s.description, "docs": "\n".join("• " + d for d in s.doc_list(LANG)),
                "resultTime": s.result_time, "note": s.note,
                "online": s.online_available, "booking": s.booking_enabled,
            })
        return rows

    def _ticket(self, t):
        state = views._ticket_state(t, LANG)
        state.update({
            "token": t.token, "service": t.service.name,
            "slot": timezone.localtime(t.slot_start).strftime("%d.%m %H:%M") if t.slot_start else "",
            "ahead": -1 if state["ahead"] is None else state["ahead"],
            "wait": -1 if state["wait"] is None else state["wait"],
            "window": state["window"] or 0,
            "canCancel": t.status in (Ticket.BOOKED, Ticket.WAITING),
            "canCheckIn": t.status == Ticket.BOOKED,
        })
        del state["position"]
        return state

    @Slot(int, result="QVariantMap")
    def takeLive(self, service_id):
        s = Service.objects.filter(pk=service_id, is_active=True).first()
        if not s:
            return {"error": "Услуга не найдена."}
        # Десктоп-терминал стоит в самом МФЦ, поэтому проверка «я на месте» (QR) не нужна.
        return self._ticket(engine.create_live_ticket(s, actor="terminal"))

    @Slot(int, result="QVariantList")
    def bookingDays(self, service_id):
        s = Service.objects.get(pk=service_id)
        if not s.booking_enabled:
            return []
        return [{"iso": d.isoformat(), "label": fmt_day(d, LANG)}
                for d in engine.booking_days() if any(free for _s, free in engine.slots_for(s, d))]

    @Slot(int, str, result="QVariantList")
    def slots(self, service_id, day_iso):
        s = Service.objects.get(pk=service_id)
        return [{"iso": start.isoformat(), "label": _hm(start), "free": free}
                for start, free in engine.slots_for(s, date.fromisoformat(day_iso))]

    @Slot(int, str, result="QVariantMap")
    def book(self, service_id, slot_iso):
        s = Service.objects.get(pk=service_id)
        try:
            return self._ticket(engine.create_booking(s, datetime.fromisoformat(slot_iso), actor="terminal"))
        except engine.QueueError as e:
            return {"error": _err(e)}

    @Slot(str, result="QVariantMap")
    def findTicket(self, number):
        """Талон по номеру (A-001): последний за 2 недели — номера повторяются каждый день."""
        engine.sweep()
        t = (Ticket.objects.filter(number__iexact=number.strip(), day__gte=timezone.localdate() - timedelta(days=14))
             .select_related("service", "window").order_by("-day", "-created_at").first())
        return self._ticket(t) if t else {"error": "Талон не найден."}

    @Slot(str, result="QVariantMap")
    def checkIn(self, token):
        t = Ticket.objects.get(token=token)
        try:
            engine.check_in(t)
        except engine.QueueError as e:
            return {"error": _err(e)}
        return self._ticket(Ticket.objects.get(pk=t.pk))

    @Slot(str, result="QVariantMap")
    def cancel(self, token):
        t = Ticket.objects.get(token=token)
        try:
            engine.cancel(t)
        except engine.QueueError as e:
            return {"error": _err(e)}
        return self._ticket(Ticket.objects.get(pk=t.pk))

    # ------------------------------------------------------------ табло
    @Slot(result="QVariantMap")
    def board(self):
        engine.sweep()
        now = timezone.now()
        fresh = set(EventLog.objects.filter(event__in=["called", "recalled"], ts__gte=now - timedelta(seconds=30))
                    .values_list("ticket_id", flat=True))
        called = (Ticket.objects.filter(status__in=[Ticket.CALLED, Ticket.SERVING], day=timezone.localdate())
                  .select_related("window").order_by("-called_at")[:8])
        waiting = engine.ordered_waiting()
        return {
            "called": [{"number": t.number, "window": t.window.number if t.window else 0, "fresh": t.pk in fresh}
                       for t in called],
            "next": [t.number for t in waiting[:6]],
            "waiting": len(waiting),
        }

    # --------------------------------------------------------- оператор
    @Slot(result="QVariantList")
    def windows(self):
        return [{"id": w.pk, "label": f"Окно {w.number}"}
                for w in Window.objects.all()]

    @Slot(result="QVariantList")
    def allServices(self):
        return [{"id": s.pk, "label": f"{s.code} — {s.name}"} for s in Service.objects.filter(is_active=True)]

    @Slot(int, result="QVariantMap")
    def windowState(self, window_id):
        if not self.isOperator:
            return {}
        engine.sweep()
        w = Window.objects.select_related("current_ticket__service").filter(pk=window_id).first()
        if not w:
            return {}
        cur = w.current_ticket if w.current_ticket and w.current_ticket.is_active else None
        ids = list(w.services.values_list("id", flat=True))
        now = timezone.now()
        queue = []
        for t in engine.ordered_waiting(ids if w.status != Window.STATUS_CLOSED else None):
            entered = t.entered_queue_at or t.created_at
            queue.append({"number": t.number, "service": t.service.name,
                          "source": tr(f"source_{t.source}") + (f" {_hm(t.slot_start)}" if t.slot_start else ""),
                          "waited": int((now - entered).total_seconds() // 60)})
        events = EventLog.objects.filter(window=w, ts__date=timezone.localdate()).select_related("ticket")[:12]
        return {
            "number": w.number, "status": w.status, "statusLabel": w.get_status_display(),
            "serviceIds": ids,
            "serviceCodes": ", ".join(w.services.values_list("code", flat=True)),
            "current": None if not cur else {
                "number": cur.number, "service": cur.service.name, "status": cur.status,
                "statusLabel": cur.get_status_display(), "source": cur.get_source_display(),
                "slot": _hm(cur.slot_start)},
            "queue": queue,
            "events": [f"{_hm(e.ts)} {e.event}" + (f" {e.ticket.number}" if e.ticket else "")
                       + (f": {e.payload}" if e.payload else "") for e in events],
            "doneToday": Ticket.objects.filter(window=w, status=Ticket.COMPLETED, day=timezone.localdate()).count(),
        }

    @Slot(int, str, "QVariant", result=str)
    def operatorAction(self, window_id, action, arg):
        """Возвращает текст для оператора (ошибка или подсказка), пустая строка — всё хорошо."""
        if not self.isOperator:
            return "Нет прав оператора."
        w = Window.objects.get(pk=window_id)
        actor = self.userName
        try:
            if action == "open":
                engine.open_window(w, [int(i) for i in arg], actor)
            elif action == "call_next":
                if engine.call_next(w, actor) is None:
                    return tr("err_queue_empty", LANG)
            elif action in ("redirect", "walkin"):
                s = Service.objects.get(pk=int(arg))
                (engine.redirect if action == "redirect" else engine.add_walkin)(w, s, actor)
            elif action == "issue":
                if not str(arg).strip():
                    raise engine.QueueError("err_note_empty")
                engine.report_issue(w, str(arg).strip(), actor)
                return "Записано в журнал событий."
            elif action in ("close_soft", "close_now"):
                engine.close_window(w, action == "close_now", actor)
            else:
                {"start": engine.start_serving, "complete": engine.complete, "recall": engine.recall,
                 "no_show": engine.mark_no_show, "return": engine.return_to_queue}[action](w, actor)
        except engine.QueueError as e:
            return _err(e)
        return ""

    # ------------------------------------------------------ руководитель
    @Slot(int, result="QVariantMap")
    def dashboard(self, days):
        if not self.isManager:
            return {}
        engine.sweep()
        st = analytics.build(days)
        dash = "—"

        def v(x, suffix=""):
            return dash if x is None else f"{x}{suffix}"

        return {
            "kpi": [
                {"title": "Обращений", "value": str(st["requests_total"])},
                {"title": "Обслужено", "value": str(st["served"])},
                {"title": "Среднее ожидание", "value": v(st["avg_wait"], " мин")},
                {"title": "Максимальное ожидание", "value": v(st["max_wait"], " мин")},
                {"title": "Вызваны в своё время", "value": v(st["in_slot_share"], " %")},
                {"title": "Неявки по записи", "value": v(st["no_show_share"], " %")},
                {"title": "Ушли в личный кабинет", "value": v(st["lk_share"], " %")},
                {"title": "Проблем зафиксировано", "value": str(st["issues"])},
            ],
            "hours": [{"label": r["label"], "arrived": r["arrived"], "pct": r["pct"], "avgWait": v(r["avg_wait"])}
                      for r in st["hours"]],
            "services": [{"name": f'{r["service"].code} — {r["service"].name}', "total": r["total"],
                          "completed": r["completed"], "avgWait": v(r["avg_wait"]),
                          "avgDuration": v(r["avg_duration"]), "norm": r["norm"], "lk": r["lk"]}
                         for r in st["services"]],
            "windows": [{"name": f'Окно {r["window"].number}', "completed": r["completed"],
                         "avgDuration": v(r["avg_duration"]), "services": r["services"]} for r in st["windows"]],
        }

    @Slot(int, QUrl, result=str)
    def exportCsv(self, days, url):
        if not self.isManager:
            return "Нет прав руководителя."
        _start, rows = analytics.export_rows(days)
        try:
            with open(url.toLocalFile(), "w", encoding="utf-8-sig", newline="") as f:  # -sig: Excel видит кириллицу
                csv.writer(f, delimiter=";").writerows(rows)
        except OSError as e:
            return f"Не удалось сохранить файл: {e}"
        return f"Сохранено строк: {len(rows) - 1}"
