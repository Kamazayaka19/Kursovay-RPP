from django.apps import AppConfig


class QueueappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "queueapp"
    verbose_name = "Электронная очередь МФЦ"
