"""
Десктоп-версия электронной очереди МФЦ (PySide6 + QML).

Запуск из корня проекта:  python desktop/main.py
Работает с той же базой db.sqlite3, что и веб-версия, — их можно запускать одновременно.
"""
import io
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
os.environ.setdefault("QT_QUICK_CONTROLS_STYLE", "Material")

import django  # noqa: E402

django.setup()

from django.core.management import call_command  # noqa: E402
from PySide6.QtGui import QGuiApplication  # noqa: E402
from PySide6.QtQml import QQmlApplicationEngine  # noqa: E402

from desktop.backend import Backend  # noqa: E402
from queueapp.models import Service  # noqa: E402


def prepare_db():
    """Первый запуск: создать таблицы и демо-данные, чтобы приложение сразу работало."""
    out = io.StringIO()  # у оконного .exe нет консоли
    call_command("migrate", interactive=False, verbosity=0, stdout=out)
    if not Service.objects.exists():
        call_command("seed_demo", history=True, stdout=out)


def main():
    prepare_db()
    app = QGuiApplication(sys.argv)
    app.setApplicationName("Электронная очередь МФЦ")
    backend = Backend()
    engine = QQmlApplicationEngine()
    engine.rootContext().setContextProperty("backend", backend)
    engine.load(Path(__file__).parent / "qml" / "Main.qml")
    if not engine.rootObjects():
        sys.exit(1)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
