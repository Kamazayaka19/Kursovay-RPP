"""
Мобильное приложение студента: электронная очередь МФЦ (Flet).

Приложение — клиент: данные хранит сервер (Django из этого же проекта),
поэтому талон с телефона сразу виден оператору в десктоп-версии и на табло.

Запуск на компьютере для проверки:  flet run mobile/main.py
Сборка APK:                         cd mobile && flet build apk
"""
import asyncio

import flet as ft

from api import Api, ApiError

GREEN = "#1b5e20"
ACTIVE = ("booked", "waiting", "called", "serving")
POLL_SECONDS = 5


async def main(page: ft.Page):
    page.title = "Студенческий МФЦ"
    page.theme = ft.Theme(color_scheme_seed=GREEN)
    page.theme_mode = ft.ThemeMode.LIGHT
    prefs = ft.SharedPreferences()
    haptic = ft.HapticFeedback()
    page.services.extend([prefs, haptic])

    st = {
        "server": await prefs.get("server") or "http://192.168.0.10:8000",
        "key": await prefs.get("key") or "",
        "token": await prefs.get("token") or "",
        "ticket": None,        # последний ответ сервера по моему талону
        "warned": False,       # уже предупредили «скоро ваша очередь»
        "tab": 0,
    }
    body = ft.ListView(expand=True, padding=16, spacing=8)

    def api():
        return Api(st["server"])

    def toast(text):
        page.show_dialog(ft.SnackBar(ft.Text(text)))

    async def call(fn, *args):
        """Сетевой запрос в фоне, чтобы интерфейс не замирал. None — ошибка уже показана."""
        try:
            return await asyncio.to_thread(fn, *args)
        except ApiError as e:
            toast(str(e))
            page.update()
            return None

    def has_active_ticket():
        return st["ticket"] is not None and st["ticket"]["status"] in ACTIVE

    async def remember(ticket):
        st["ticket"], st["token"], st["warned"] = ticket, ticket["token"], False
        await prefs.set("token", ticket["token"])
        nav.selected_index = 1
        await show(1)

    def wait_text(s):
        if s["wait"] is None:
            return "окна сейчас закрыты"
        if s["waiting"] == 0:
            return "без очереди"
        return f"в очереди {s['waiting']} · ожидание ≈ {s['wait']} мин"

    # ------------------------------------------------------------ Услуги
    async def show_services():
        data = await call(api().services)
        if data is None:
            body.controls = [ft.Text("Не удалось загрузить услуги."), ft.Button("Повторить", on_click=on_tab_retry)]
            return
        st["lk_url"] = data["lk_url"]
        body.controls = [ft.Text("Какая услуга вам нужна?", size=22, weight=ft.FontWeight.BOLD)]
        category = None
        for s in data["services"]:
            if s["category"] != category:
                category = s["category"]
                body.controls.append(ft.Text(category, color=GREEN, weight=ft.FontWeight.BOLD))
            body.controls.append(ft.Card(content=ft.ListTile(
                leading=ft.CircleAvatar(content=ft.Text(s["code"])),
                title=ft.Text(s["name"]),
                subtitle=ft.Text(wait_text(s)),
                data=s,
                on_click=on_service_click,
            )))

    async def on_service_click(e):
        await show_service(e.control.data)
        page.update()

    async def show_service(s):
        st["service"] = s
        c = [
            ft.TextButton("Все услуги", icon=ft.Icons.ARROW_BACK, on_click=on_tab_retry),
            ft.Text(f"{s['code']} — {s['name']}", size=20, weight=ft.FontWeight.BOLD),
            ft.Text(s["description"]),
        ]
        if s["docs"]:
            c += [ft.Text("Что взять с собой", weight=ft.FontWeight.BOLD)] + [ft.Text("• " + d) for d in s["docs"]]
        if s["result_time"]:
            c.append(ft.Text(f"Срок готовности: {s['result_time']}"))
        if s["note"]:
            c.append(ft.Text("Важно: " + s["note"], color=ft.Colors.ORANGE_900))
        if s["online"]:
            c.append(ft.OutlinedButton("Заказать в личном кабинете — без очереди", url=st.get("lk_url")))
        c += [ft.Text(wait_text(s), color=ft.Colors.GREY_700),
              ft.FilledButton("Я в МФЦ — встать в живую очередь", icon=ft.Icons.DIRECTIONS_WALK, on_click=on_live)]
        if s["booking"]:
            c.append(ft.Text("Записаться на время", size=18, weight=ft.FontWeight.BOLD))
            days = await call(api().slots, s["id"])
            if days:
                slot_row = ft.Row(wrap=True, spacing=6)
                st["days"] = {d["day"]: d for d in days}

                def fill(day):
                    slot_row.controls = [
                        ft.Button(x["label"], data=x["start"], disabled=x["free"] == 0, on_click=on_book)
                        for x in st["days"][day]["slots"]]

                def on_day(e):
                    fill(e.control.value)
                    page.update()

                fill(days[0]["day"])
                c += [ft.Dropdown(value=days[0]["day"], on_select=on_day,
                                  options=[ft.DropdownOption(key=d["day"], text=d["label"]) for d in days]),
                      slot_row]
            elif days is not None:
                c.append(ft.Text("Свободного времени нет."))
        c.append(ft.Text("Мы не спрашиваем ФИО, телефон и номер зачётки. Талон — это номер, услуга и время.",
                         size=12, color=ft.Colors.GREY_600))
        body.controls = c

    async def on_live(e):
        if has_active_ticket():
            toast("У вас уже есть активный талон.")
            return
        if not st["key"]:
            toast("Введите код с QR-таблички на стойке МФЦ во вкладке «Настройки».")
            return
        ticket = await call(api().take_live, st["service"]["id"], st["key"])
        if ticket:
            await remember(ticket)
        page.update()

    async def on_book(e):
        if has_active_ticket():
            toast("У вас уже есть активный талон.")
            return
        ticket = await call(api().book, st["service"]["id"], e.control.data)
        if ticket:
            await remember(ticket)
        page.update()

    # ---------------------------------------------------------- Мой талон
    async def show_ticket():
        if st["token"] and st["ticket"] is None:
            st["ticket"] = await call(api().ticket, st["token"])
        t = st["ticket"]
        if not t:
            body.controls = [ft.Text("У вас нет талона.", size=18),
                             ft.Text("Выберите услугу во вкладке «Услуги».", color=ft.Colors.GREY_700)]
            return
        c = [
            ft.Text(t["number"], size=64, weight=ft.FontWeight.BOLD, color=GREEN, text_align=ft.TextAlign.CENTER),
            ft.Text(t["service"]),
            ft.Text(f"Статус: {t['status_label']}", size=18, weight=ft.FontWeight.BOLD),
        ]
        if t["slot"]:
            c.append(ft.Text(f"Время записи: {t['slot']}"))
        if t["ahead"] is not None:
            c.append(ft.Text(f"Перед вами: {t['ahead']}" +
                             (f" · ожидание ≈ {t['wait']} мин" if t["wait"] is not None else " · окна закрыты")))
        if t["window"]:
            c.append(ft.Text(f"Пройдите к окну {t['window']}", size=26, weight=ft.FontWeight.BOLD,
                             color=ft.Colors.RED_800))
        if t["can_checkin"]:
            c.append(ft.FilledButton("Я на месте", icon=ft.Icons.CHECK, data="checkin", on_click=on_ticket_action))
        if t["can_cancel"]:
            c.append(ft.TextButton("Отменить талон", data="cancel", on_click=on_ticket_action))
        c.append(ft.Text("Держите приложение открытым — телефон завибрирует, когда подойдёт очередь.",
                         size=12, color=ft.Colors.GREY_600))
        body.controls = c

    async def on_ticket_action(e):
        t = await call(getattr(api(), e.control.data), st["token"])
        if t:
            st["ticket"] = t
            await show_ticket()
        page.update()

    async def poll():
        """Раз в 5 секунд обновляет талон и предупреждает вибрацией."""
        while True:
            await asyncio.sleep(POLL_SECONDS)
            if not has_active_ticket():
                continue
            try:
                t = await asyncio.to_thread(api().ticket, st["token"])
            except ApiError:
                continue  # нет сети — попробуем в следующий раз, талон на сервере не пропадёт
            old = st["ticket"]["status"]
            st["ticket"] = t
            if t["status"] == "called" and old != "called":
                await haptic.heavy_impact()
                page.show_dialog(ft.AlertDialog(title=ft.Text(f"Вас вызывают! {t['number']}"),
                                                content=ft.Text(f"Пройдите к окну {t['window']}")))
            elif t["wait"] is not None and t["ahead"] <= t["notify_ahead"] and not st["warned"]:  # wait есть только при открытых окнах
                st["warned"] = True
                await haptic.medium_impact()
                toast(f"Скоро ваша очередь: перед вами {t['ahead']}.")
            if st["tab"] == 1:
                await show_ticket()
            page.update()

    # ---------------------------------------------------------- Настройки
    async def show_settings():
        server = ft.TextField(label="Адрес сервера МФЦ", value=st["server"], keyboard_type=ft.KeyboardType.URL)
        key = ft.TextField(label="Код со стойки МФЦ", value=st["key"])

        async def save(e):
            st["server"], st["key"] = server.value.strip(), key.value.strip()
            await prefs.set("server", st["server"])
            await prefs.set("key", st["key"])
            toast("Сохранено.")
            page.update()

        body.controls = [
            ft.Text("Настройки", size=22, weight=ft.FontWeight.BOLD), server, key,
            ft.FilledButton("Сохранить", on_click=save),
            ft.Text("Адрес — компьютер, где запущен сервер: python manage.py runserver 0.0.0.0:8000. "
                    "Код напечатан на QR-табличке у входа (демо: mfc-stand-demo).",
                    size=12, color=ft.Colors.GREY_600),
        ]

    # ---------------------------------------------------------- Навигация
    async def show(tab):
        st["tab"] = tab
        await [show_services, show_ticket, show_settings][tab]()
        page.update()

    async def on_tab(e):
        await show(e.control.selected_index)

    async def on_tab_retry(e):
        await show(st["tab"])

    nav = ft.NavigationBar(selected_index=0, on_change=on_tab, destinations=[
        ft.NavigationBarDestination(icon=ft.Icons.LIST_ALT, label="Услуги"),
        ft.NavigationBarDestination(icon=ft.Icons.CONFIRMATION_NUMBER, label="Мой талон"),
        ft.NavigationBarDestination(icon=ft.Icons.SETTINGS, label="Настройки"),
    ])
    page.navigation_bar = nav
    page.appbar = ft.AppBar(title=ft.Text("Студенческий МФЦ"), bgcolor=GREEN, color=ft.Colors.WHITE)
    page.add(body)
    if st["token"]:
        st["ticket"] = await call(api().ticket, st["token"])
    await show(0)
    page.run_task(poll)


if __name__ == "__main__":
    ft.run(main)
