"""
Интерфейс администратора МФЦ: справочник услуг, окна, пользователи и роли
меняются без разработчиков (ПР №3, сторона №19). Талоны и журнал — только просмотр.
"""
from django.contrib import admin

from .models import EventLog, Service, Ticket, Window


@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "category", "avg_time_min", "online_available",
                    "booking_enabled", "slot_capacity", "is_active", "order")
    list_editable = ("avg_time_min", "online_available", "booking_enabled", "slot_capacity", "is_active", "order")
    list_filter = ("category", "online_available", "is_active")
    search_fields = ("name", "name_en", "code")
    fieldsets = (
        (None, {"fields": ("code", "name", "category", "is_active", "order")}),
        ("Регламент", {"fields": ("description", "documents", "result_time", "note", "avg_time_min")}),
        ("Каналы", {"fields": ("online_available", "booking_enabled", "slot_capacity")}),
        ("English", {"classes": ("collapse",),
                     "fields": ("name_en", "description_en", "documents_en", "result_time_en", "note_en")}),
    )


@admin.register(Window)
class WindowAdmin(admin.ModelAdmin):
    list_display = ("number", "status", "current_ticket")
    filter_horizontal = ("services",)
    readonly_fields = ("current_ticket",)


class ReadOnlyAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return request.user.is_superuser


@admin.register(Ticket)
class TicketAdmin(ReadOnlyAdmin):
    list_display = ("number", "day", "service", "source", "status", "slot_start", "called_at", "window")
    list_filter = ("status", "source", "day", "service")
    search_fields = ("number",)
    date_hierarchy = "day"
    exclude = ("token",)


@admin.register(EventLog)
class EventLogAdmin(ReadOnlyAdmin):
    list_display = ("ts", "event", "ticket", "window", "service", "payload", "actor")
    list_filter = ("event", "window")
    date_hierarchy = "ts"
