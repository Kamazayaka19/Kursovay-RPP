"""
Клиент JSON-API сервера МФЦ (Django). Только стандартная библиотека —
так приложение без лишних зависимостей собирается под Android.
"""
import json
import urllib.error
import urllib.parse
import urllib.request


class ApiError(Exception):
    """Текст ошибки, который можно показать студенту."""


class Api:
    def __init__(self, base_url):
        self.base = base_url.rstrip("/")

    def _call(self, path, data=None):
        body = urllib.parse.urlencode(data).encode() if data is not None else None  # POST, если есть данные
        try:
            with urllib.request.urlopen(f"{self.base}/api/{path}", data=body, timeout=8) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            try:
                raise ApiError(json.loads(e.read())["error"]) from None
            except (ValueError, KeyError):
                raise ApiError(f"Ошибка сервера ({e.code})") from None
        except (urllib.error.URLError, OSError):
            raise ApiError("Нет связи с сервером МФЦ. Проверьте Wi-Fi и адрес в настройках.") from None

    def services(self):
        return self._call("services/")

    def slots(self, service_id):
        return self._call(f"services/{service_id}/slots/")["days"]

    def take_live(self, service_id, key):
        return self._call(f"services/{service_id}/live/", {"key": key})

    def book(self, service_id, slot_iso):
        return self._call(f"services/{service_id}/book/", {"slot": slot_iso})

    def ticket(self, token):
        return self._call(f"ticket/{token}/")

    def checkin(self, token):
        return self._call(f"ticket/{token}/checkin/", {})

    def cancel(self, token):
        return self._call(f"ticket/{token}/cancel/", {})
