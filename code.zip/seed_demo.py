"""
python manage.py seed_demo            — услуги, окна, роли и демо-пользователи
python manage.py seed_demo --history  — плюс 2 недели обезличенной истории для дашборда

Справки A–F и сроки взяты со страницы МФЦ на timacad.ru; остальные услуги —
примерные, администратор МФЦ уточняет их через /admin/.

python manage.py seed_demo --update  — обновить уже созданные услуги
"""
import random
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.core.management.base import BaseCommand
from django.utils import timezone

from queueapp import roles
from queueapp.engine import _aware, _hm
from queueapp.models import EventLog, Service, Ticket, Window
from django.conf import settings

SERVICES = [
    # Справки — по перечню и срокам со страницы МФЦ на timacad.ru
    dict(code="A", order=10, category="certs", avg_time_min=3, online_available=True,
         name="Справка о подтверждении обучения по месту требования",
         name_en="Certificate of enrolment (for any recipient)",
         description="Подтверждает, что вы учитесь: курс, форма обучения, направление и период освоения программы.",
         description_en="Confirms that you are a student: year, mode of study, programme and study period.",
         documents="Паспорт или студенческий билет", documents_en="Passport or student card",
         result_time="до 7 рабочих дней", result_time_en="up to 7 working days",
         note="Не больше 3 справок в одном заказе", note_en="Up to 3 certificates per order"),
    dict(code="B", order=20, category="certs", avg_time_min=4, online_available=True,
         name="Справка о подтверждении обучения с гербовой печатью",
         name_en="Certificate of enrolment with official seal",
         description="То же подтверждение обучения, но с гербовой печатью: для соцзащиты, Социального фонда, "
                     "отдела субсидий, опеки и для зарубежных стран.",
         description_en="Enrolment certificate with the official seal: for social services, the Social Fund, "
                        "subsidies, guardianship and foreign countries.",
         documents="Паспорт или студенческий билет", documents_en="Passport or student card",
         result_time="до 7 рабочих дней", result_time_en="up to 7 working days",
         note="Не больше 3 справок в одном заказе", note_en="Up to 3 certificates per order"),
    dict(code="C", order=30, category="certs", avg_time_min=3, online_available=True,
         name="Справка о стипендии и иных доходах", name_en="Certificate of grant and other income",
         description="Сведения о начисленной стипендии и других выплатах за выбранный период.",
         description_en="Your grant and other payments for the chosen period.",
         documents="Паспорт или студенческий билет", documents_en="Passport or student card",
         result_time="до 7 рабочих дней", result_time_en="up to 7 working days",
         note="Период должен заканчиваться раньше месяца, в котором вы заказываете справку",
         note_en="The period must end before the month in which you order"),
    dict(code="D", order=40, category="certs", avg_time_min=6, online_available=False,
         name="Справка о периоде обучения", name_en="Certificate of study period",
         description="Оформляется по Положению о выдаче документов академии.",
         description_en="Issued under the university's regulations on documents.",
         documents="Паспорт или студенческий билет", documents_en="Passport or student card",
         result_time="5 рабочих дней при переводе в другой вуз, в остальных случаях до 30 дней",
         result_time_en="5 working days for a transfer, otherwise up to 30 days"),
    dict(code="E", order=50, category="certs", avg_time_min=3, online_available=True,
         name="Справка-вызов", name_en="Study leave certificate (spravka-vyzov)",
         description="Для работодателя по статье 173 Трудового кодекса. Отрывную часть выдаёт дирекция института.",
         description_en="For your employer under Article 173 of the Labour Code. The tear-off part is issued by your institute.",
         documents="Паспорт или студенческий билет", documents_en="Passport or student card",
         result_time="до 10 рабочих дней", result_time_en="up to 10 working days"),
    dict(code="F", order=60, category="certs", avg_time_min=2, online_available=True, booking_enabled=False,
         name="Справка о подтверждении обучения с электронной подписью",
         name_en="Enrolment certificate with electronic signature",
         description="Электронная справка — оформляется и выдаётся только в личном кабинете, в МФЦ идти не нужно.",
         description_en="An electronic certificate — ordered and received only in your personal account.",
         documents="", documents_en="",
         result_time="до 3 рабочих дней", result_time_en="up to 3 working days",
         note="Получение только в личном кабинете", note_en="Available only in the personal account"),
    # Заявления, выписки, выдача — для пилота; уточнить с МФЦ
    dict(code="G", order=70, category="apps", avg_time_min=7, online_available=False,
         name="Приём заявлений (академический отпуск, перевод, восстановление и др.)",
         name_en="Applications (academic leave, transfer, reinstatement, etc.)",
         description="Приём заявления и передача его в дирекцию института.",
         description_en="We accept your application and pass it to your institute.",
         documents="Паспорт\nСтуденческий билет\nПодтверждающие документы по виду заявления",
         documents_en="Passport\nStudent card\nSupporting documents for your application",
         result_time="по регламенту дирекции", result_time_en="per institute rules"),
    dict(code="H", order=80, category="orders", avg_time_min=4, online_available=False,
         name="Выписка из приказа", name_en="Extract from an order",
         description="Копия нужного пункта приказа о вас (зачисление, перевод, отчисление и др.).",
         description_en="An extract from a university order concerning you (enrolment, transfer, etc.).",
         documents="Паспорт или студенческий билет", documents_en="Passport or student card",
         result_time="уточняется в МФЦ", result_time_en="check with the centre"),
    dict(code="I", order=90, category="pickup", avg_time_min=2, online_available=False,
         name="Получение готовых документов", name_en="Collecting ready documents",
         description="Выдача справок и документов, заказанных в личном кабинете или в МФЦ.",
         description_en="Pick up documents ordered online or at the centre.",
         documents="Паспорт или студенческий билет", documents_en="Passport or student card",
         result_time="сразу", result_time_en="immediately"),
    dict(code="J", order=100, category="staff", avg_time_min=4, online_available=False,
         name="Справки для преподавателей и сотрудников", name_en="Certificates for staff",
         description="Справка с места работы и другие документы для сотрудников академии (перечень уточнить с МФЦ).",
         description_en="Employment certificate and other staff documents (list to be confirmed).",
         documents="Паспорт или пропуск сотрудника", documents_en="Passport or staff pass",
         result_time="уточняется в МФЦ", result_time_en="check with the centre"),
]

WINDOWS_COUNT = 8  # в зале МФЦ восемь окон приёма

DEMO_PASSWORD = "demo12345"


class Command(BaseCommand):
    help = "Наполняет базу демо-данными для показа прототипа"

    def add_arguments(self, parser):
        parser.add_argument("--history", action="store_true", help="добавить 2 недели истории для дашборда")
        parser.add_argument("--update", action="store_true",
                            help="перезаписать услуги с теми же буквами актуальным справочником")

    def handle(self, *args, **opts):
        created = updated = 0
        for data in SERVICES:
            if opts["update"]:
                _, was_created = Service.objects.update_or_create(code=data["code"], defaults=data)
                updated += not was_created
            else:
                _, was_created = Service.objects.get_or_create(code=data["code"], defaults=data)
            created += was_created
        if opts["update"]:
            known = [d["code"] for d in SERVICES]
            hidden = Service.objects.exclude(code__in=known).update(is_active=False)
            self.stdout.write(f"Услуги: обновлено {updated}, скрыто устаревших {hidden}")
        self.stdout.write(f"Услуги: добавлено {created}, всего {Service.objects.count()}")

        for n in range(1, WINDOWS_COUNT + 1):
            Window.objects.get_or_create(number=n)
        self.stdout.write(f"Окна: {Window.objects.count()}")

        self._roles()
        if opts["history"]:
            self._history()
        self.stdout.write(self.style.SUCCESS("Готово."))

    def _roles(self):
        def perms(*codenames):
            return list(Permission.objects.filter(codename__in=codenames))

        op, _ = Group.objects.get_or_create(name=roles.OPERATOR)
        mgr, _ = Group.objects.get_or_create(name=roles.MANAGER)
        adm, _ = Group.objects.get_or_create(name=roles.ADMIN)
        adm.permissions.set(perms(
            "add_service", "change_service", "view_service",
            "add_window", "change_window", "view_window",
            "view_ticket", "view_eventlog",
            "add_user", "change_user", "view_user", "view_group",
        ))
        mgr.permissions.set(perms("view_service", "view_window", "view_ticket", "view_eventlog"))

        User = get_user_model()
        demo = [
            ("operator1", op, False),
            ("operator2", op, False),
            ("manager", mgr, False),
            ("mfcadmin", adm, True),
        ]
        for username, group, staff in demo:
            user, was_created = User.objects.get_or_create(username=username, defaults={"is_staff": staff})
            if was_created:
                user.set_password(DEMO_PASSWORD)
                user.save()
            user.groups.add(group)
        self.stdout.write(
            "Пользователи: operator1, operator2 (оператор), manager (руководитель), "
            f"mfcadmin (администратор). Пароль: {DEMO_PASSWORD} — смените перед пилотом!"
        )

    def _history(self):
        if Ticket.objects.filter(day__lt=timezone.localdate()).exists():
            self.stdout.write("История уже есть — пропускаю.")
            return
        rnd = random.Random(42)
        cfg = settings.QUEUE
        services = list(Service.objects.all())
        windows = list(Window.objects.filter(number__lte=2))  # пилот на 1–2 окнах
        h_from, _ = _hm(cfg["WORK_START"])
        h_to, _ = _hm(cfg["WORK_END"])
        hour_weights = {h: (3 if h in (10, 11, 15) else 2 if h in (12, 14, 16) else 1) for h in range(h_from, h_to)}
        lunch = cfg.get("LUNCH")
        lunch_hours = set(range(_hm(lunch[0])[0], _hm(lunch[1])[0])) if lunch else set()

        tickets, events = [], []
        today = timezone.localdate()
        for back in range(14, 0, -1):
            day = today - timedelta(days=back)
            if day.weekday() not in cfg["WORK_DAYS"]:
                continue
            counters = {s.pk: 0 for s in services}
            for _ in range(rnd.randint(28, 48)):
                s = rnd.choice(services)
                hours = [h for h in hour_weights if h not in lunch_hours]
                h = rnd.choices(hours, weights=[hour_weights[x] for x in hours])[0]
                counters[s.pk] += 1
                number = f"{s.code}-{counters[s.pk]:03d}"
                booking = rnd.random() < 0.35
                minute = rnd.choice([0, 15, 30, 45]) if booking else rnd.randint(0, 59)
                if h == h_from:
                    minute = max(minute, _hm(cfg["WORK_START"])[1])
                slot = _aware(day, (h, minute)) if booking else None
                created = (slot - timedelta(days=rnd.randint(0, 3), hours=rnd.randint(1, 5))) if booking \
                    else _aware(day, (h, minute))
                if booking and rnd.random() < 0.1:
                    tickets.append(Ticket(number=number, day=day, service=s, source="booking",
                                          status=Ticket.NO_SHOW, slot_start=slot, created_at=created))
                    continue
                entered = slot - timedelta(minutes=rnd.randint(0, 12)) if booking else created
                wait = rnd.uniform(1, 9) if booking else rnd.uniform(3, 28 if h in (10, 11, 15) else 14)
                called = entered + timedelta(minutes=wait)
                serving = called + timedelta(minutes=rnd.uniform(0.3, 1.5))
                done = serving + timedelta(minutes=max(1, rnd.gauss(s.avg_time_min, 1.5)))
                tickets.append(Ticket(number=number, day=day, service=s, source="booking" if booking else "qr",
                                      status=Ticket.COMPLETED, slot_start=slot, created_at=created,
                                      entered_queue_at=entered, called_at=called, serving_at=serving,
                                      completed_at=done, window=rnd.choice(windows)))
            for _ in range(rnd.randint(4, 12)):
                s = rnd.choice([x for x in services if x.online_available])
                events.append(EventLog(event="lk_redirect", service=s, actor="client",
                                       ts=_aware(day, (rnd.randint(h_from, h_to - 1), rnd.randint(0, 59)))))
        Ticket.objects.bulk_create(tickets)
        EventLog.objects.bulk_create(events)
        self.stdout.write(f"История: {len(tickets)} талонов, {len(events)} переходов в личный кабинет")
