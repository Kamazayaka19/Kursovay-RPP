from django import template

from .. import i18n

register = template.Library()


@register.simple_tag(takes_context=True)
def t(context, key, **kwargs):
    """{% t "key" %} — строка интерфейса на текущем языке."""
    return i18n.tr(key, context.get("lang", "ru"), **kwargs)


@register.simple_tag(takes_context=True)
def loc(context, obj, field):
    """{% loc service "name" %} — поле модели на текущем языке (с откатом на русский)."""
    if context.get("lang") == "en":
        value = getattr(obj, f"{field}_en", "")
        if value:
            return value
    return getattr(obj, field, "")


@register.simple_tag(takes_context=True)
def day_label(context, day):
    return i18n.fmt_day(day, context.get("lang", "ru"))
