"""
Простой двуязычный интерфейс (RU/EN) без сборки .po/.mo-файлов:
так его легко поправить без инструментов gettext на Windows.
Добавлен по итогам ПР №3 (иностранные студенты, сторона №15).
"""

STRINGS = {
    # Общее
    "brand": ("Студенческий МФЦ", "Student Service Centre"),
    "brand_sub": ("Электронная очередь", "Digital queue"),
    "nav_services": ("Услуги", "Services"),
    "nav_my_ticket": ("Мой талон", "My ticket"),
    "nav_board": ("Табло", "Display board"),
    "nav_operator": ("Окно оператора", "Operator desk"),
    "nav_dashboard": ("Нагрузка", "Workload"),
    "nav_admin": ("Настройки", "Settings"),
    "nav_login": ("Вход для сотрудников", "Staff login"),
    "nav_logout": ("Выйти", "Log out"),
    "a11y_on": ("Крупный шрифт", "Large text"),
    "a11y_off": ("Обычный шрифт", "Standard text"),
    "privacy_note": (
        "Мы не спрашиваем ФИО, телефон и номер зачётки. Талон — это номер, услуга и время.",
        "We never ask for your name, phone or student ID. A ticket is just a number, a service and a time.",
    ),
    "minutes": ("мин", "min"),
    "uni_name": ("РГАУ-МСХА имени К.А. Тимирязева", "Russian State Agrarian University – Moscow Timiryazev Agricultural Academy"),
    "note": ("Важно", "Note"),
    "footer_hours": ("Приём: пн–пт", "Open: Mon–Fri"),
    "footer_contacts": ("Контакты МФЦ", "Centre contacts"),
    "footer_lk": ("Личный кабинет студента", "Student personal account"),
    "footer_site": ("Страница МФЦ на сайте академии", "Centre page on the university website"),
    "back": ("Назад", "Back"),
    "window": ("Окно", "Window"),

    # Справочник
    "home_title": ("Какая услуга вам нужна?", "Which service do you need?"),
    "home_lead": (
        "Посмотрите, что взять с собой и сколько ждать. Запишитесь на удобное время "
        "или возьмите талон по QR-коду на стойке МФЦ.",
        "Check what to bring and how long the wait is. Book a time slot, or take a ticket "
        "with the QR code at the service centre desk.",
    ),
    "onsite_banner": (
        "Вы в МФЦ — можно встать в живую очередь прямо сейчас.",
        "You are at the centre — you can join the live queue now.",
    ),
    "in_queue_now": ("в очереди", "in queue"),
    "wait_about": ("ожидание около", "wait about"),
    "windows_closed": ("окна сейчас закрыты", "desks are closed now"),
    "no_wait": ("без очереди", "no queue"),
    "online_badge": ("Можно онлайн", "Available online"),
    "cat_certs": ("Справки", "Certificates"),
    "cat_apps": ("Заявления", "Applications"),
    "cat_orders": ("Выписки из приказов", "Extracts from orders"),
    "cat_pickup": ("Выдача готовых документов", "Collecting documents"),
    "cat_staff": ("Для преподавателей и сотрудников", "For teaching and other staff"),
    "cat_other": ("Другое", "Other"),

    # Карточка услуги
    "bring": ("Что взять с собой", "What to bring"),
    "bring_empty": ("Документы уточняются у специалиста МФЦ.", "Please check the documents with the centre staff."),
    "avg_time": ("Приём занимает", "Appointment takes"),
    "result_time": ("Срок готовности", "Ready in"),
    "online_title": ("Эту услугу можно заказать без визита", "You can order this without visiting"),
    "online_text": (
        "Закажите справку в личном кабинете студента — в МФЦ ехать не придётся.",
        "Order it in your student personal account — no need to come to the centre.",
    ),
    "online_btn": ("Заказать в личном кабинете", "Order in personal account"),
    "book_btn": ("Записаться на время", "Book a time slot"),
    "live_btn": ("Встать в живую очередь", "Join the live queue"),
    "live_hint": (
        "Живая очередь доступна, когда вы в МФЦ: отсканируйте QR-код на стойке.",
        "The live queue opens when you are at the centre: scan the QR code at the desk.",
    ),
    "booking_off": ("Запись на эту услугу не ведётся.", "Booking is not available for this service."),

    # Запись
    "book_title": ("Запись на время", "Book a time slot"),
    "book_day": ("День", "Day"),
    "book_pick": ("Выберите время", "Pick a time"),
    "book_free": ("свободно", "free"),
    "book_full": ("занято", "full"),
    "book_none": (
        "На этот день свободного времени нет. Выберите другой день.",
        "No free slots on this day. Please choose another day.",
    ),
    "book_confirm": ("Записаться", "Book"),
    "book_rule": (
        "Приходите к своему времени и нажмите «Я на месте» на странице талона — "
        "вас вызовут раньше живой очереди. Отметиться можно за {early} мин до слота и до {grace} мин после.",
        "Come at your time and press “I'm here” on the ticket page — you will be called ahead of the live queue. "
        "You can check in from {early} min before the slot until {grace} min after.",
    ),

    # Талон
    "ticket_title": ("Ваш талон", "Your ticket"),
    "service": ("Услуга", "Service"),
    "position": ("Перед вами", "Ahead of you"),
    "people": ("чел.", "people"),
    "your_turn_soon": ("вы следующий", "you are next"),
    "est_wait": ("Примерное ожидание", "Estimated wait"),
    "slot": ("Ваше время", "Your time"),
    "checkin_btn": ("Я на месте", "I'm here"),
    "checkin_from": ("Отметиться можно с", "Check-in opens at"),
    "cancel_btn": ("Отменить талон", "Cancel ticket"),
    "cancel_confirm": ("Отменить талон?", "Cancel this ticket?"),
    "go_to_window": ("Подойдите к окну", "Please go to window"),
    "serving_now": ("Вас обслуживают", "You are being served"),
    "closed_text": ("Талон закрыт.", "This ticket is closed."),
    "new_ticket": ("Выбрать услугу", "Choose a service"),
    "notify_btn": ("Предупредить, когда подойдёт очередь", "Notify me when my turn is near"),
    "notify_on": ("Уведомления включены: оставьте эту вкладку открытой.", "Notifications are on: keep this tab open."),
    "notify_denied": (
        "Браузер запретил уведомления — следите за статусом на этой странице.",
        "Your browser blocked notifications — keep an eye on this page.",
    ),
    "notify_near": ("Скоро ваша очередь", "Your turn is near"),
    "notify_called": ("Вас вызывают", "You are being called"),
    "open_on_phone": ("Откройте талон на телефоне", "Open this ticket on your phone"),
    "keep_link": (
        "Страница талона сохраняется: можно закрыть вкладку и вернуться через «Мой талон».",
        "This page is saved: you can close the tab and come back via “My ticket”.",
    ),
    "already_have": (
        "У вас уже есть активный талон. Отмените его, чтобы взять новый.",
        "You already have an active ticket. Cancel it to take a new one.",
    ),
    "no_my_ticket": ("Активного талона нет. Выберите услугу.", "No active ticket. Choose a service."),
    "checked_in": ("Отметка принята — вы в очереди.", "Checked in — you are in the queue."),
    "cancelled_ok": ("Талон отменён.", "Ticket cancelled."),
    "onsite_ok": ("Вы в МФЦ: выберите услугу и встаньте в очередь.", "You are at the centre: choose a service and join the queue."),

    # Статусы
    "status_booked": ("Записан на время", "Booked"),
    "status_waiting": ("В очереди", "Waiting"),
    "status_called": ("Вызван", "Called"),
    "status_serving": ("Обслуживается", "Being served"),
    "status_completed": ("Обслужен", "Completed"),
    "status_no_show": ("Не явился", "No-show"),
    "status_cancelled": ("Отменён", "Cancelled"),
    "source_booking": ("запись", "booking"),
    "source_qr": ("QR", "QR"),
    "source_walkin": ("без талона", "walk-in"),

    # Табло
    "board_title": ("Приглашаем", "Now serving"),
    "board_ticket": ("Талон", "Ticket"),
    "board_window": ("Окно", "Window"),
    "board_next": ("Следующие", "Up next"),
    "board_waiting": ("Ожидают", "Waiting"),
    "board_empty": ("Сейчас никого не вызывают", "Nobody is being called right now"),
    "board_scan": ("Талон в живую очередь — по QR-коду", "Scan the QR code to join the queue"),

    # Ошибки
    "err_booking_disabled": ("Запись на эту услугу не ведётся.", "Booking is not available for this service."),
    "err_slot_full": ("Это время уже занято — выберите другое.", "This slot is taken — please choose another."),
    "err_not_booked": ("Отметка нужна только для записи на время.", "Check-in applies to booked tickets only."),
    "err_checkin_early": ("Ещё рано — отметьтесь ближе к своему времени.", "Too early — check in closer to your slot."),
    "err_checkin_late": ("Время записи прошло. Возьмите талон в живую очередь.", "Your slot has passed. Please join the live queue."),
    "err_cannot_cancel": ("Этот талон уже нельзя отменить.", "This ticket can no longer be cancelled."),
    "err_not_onsite": ("Живая очередь доступна только в МФЦ — отсканируйте QR-код на стойке.",
                       "The live queue is only available at the centre — scan the QR code at the desk."),
    "err_window_not_open": ("Окно закрыто. Откройте его, чтобы вызывать клиентов.", "The window is closed. Open it to call clients."),
    "err_window_busy": ("У окна уже есть клиент. Завершите приём.", "This window already has a client. Finish first."),
    "err_choose_services": ("Отметьте хотя бы одну услугу окна.", "Select at least one service for this window."),
    "err_no_current": ("У окна сейчас нет клиента.", "There is no client at this window."),
    "err_queue_empty": ("Очередь пуста.", "The queue is empty."),
    "err_note_empty": ("Опишите проблему в поле.", "Describe the problem first."),
    "err_bad_slot": ("Не удалось прочитать выбранное время.", "Could not read the selected time."),
}

MONTHS = {
    "ru": ["января", "февраля", "марта", "апреля", "мая", "июня", "июля",
           "августа", "сентября", "октября", "ноября", "декабря"],
    "en": ["January", "February", "March", "April", "May", "June", "July",
           "August", "September", "October", "November", "December"],
}
WEEKDAYS = {
    "ru": ["пн", "вт", "ср", "чт", "пт", "сб", "вс"],
    "en": ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
}

LANGS = ("ru", "en")


def tr(key, lang="ru", **kwargs):
    pair = STRINGS.get(key)
    if pair is None:
        return key
    text = pair[1] if lang == "en" and pair[1] else pair[0]
    return text.format(**kwargs) if kwargs else text


def fmt_day(day, lang="ru"):
    wd = WEEKDAYS[lang][day.weekday()]
    if lang == "en":
        return f"{wd}, {MONTHS['en'][day.month - 1]} {day.day}"
    return f"{wd}, {day.day} {MONTHS['ru'][day.month - 1]}"
