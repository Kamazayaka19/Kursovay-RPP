import csv
import secrets
import time
from datetime import date, datetime, timedelta

import qrcode
import qrcode.image.svg
from django.conf import settings
from django.contrib import messages
from django.db import connection
from django.db.models import Count
from django.http import Http404, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

from . import analytics, engine, roles
from .i18n import LANGS, fmt_day, tr
from .models import EventLog, Service, Ticket, Window

ONSITE_SECONDS = 4 * 60 * 60


# ---------------------------------------------------------------------------
# Вспомогательное
# ---------------------------------------------------------------------------

def _lang(request):
    return request.session.get("lang", "ru")


def _err(request, exc):
    messages.error(request, tr(exc.code, _lang(request)))


def _is_onsite(request):
    return request.session.get("onsite_until", 0) > time.time()


def _active_session_ticket(request):
    token = request.session.get("my_token")
    if not token:
        return None
    t = Ticket.objects.filter(token=token).first()
    return t if t and t.is_active else None


def _remember(request, ticket):
    request.session["my_token"] = ticket.token


def qr_svg(data):
    img = qrcode.make(data, image_factory=qrcode.image.svg.SvgPathImage, box_size=10, border=2)
    return img.to_string(encoding="unicode")


def _queue_snapshot():
    """Сколько ждут и прогноз по каждой услуге — для справочника."""
    waiting = dict(
        Ticket.objects.filter(status=Ticket.WAITING).order_by().values_list("service").annotate(c=Count("id"))
    )
    open_counts = dict(
        Window.objects.filter(status=Window.STATUS_OPEN).order_by()
        .values_list("services").annotate(c=Count("id"))
    )
    return waiting, open_counts


def _wait_for(service, waiting, open_counts):
    n = waiting.get(service.pk, 0)
    windows = open_counts.get(service.pk, 0)
    if windows == 0:
        return n, None
    return n, -(-n * service.avg_time_min // windows)  # округление вверх


# ---------------------------------------------------------------------------
# Клиент: справочник, запись, талон
# ---------------------------------------------------------------------------

def home(request):
    engine.sweep()
    waiting, open_counts = _queue_snapshot()
    groups = []
    services = list(Service.objects.filter(is_active=True))
    known = [code for code, _label in Service.CATEGORY_CHOICES]
    for code in known:
        items = []
        for s in services:
            category = s.category if s.category in known else "other"
            if category != code:
                continue
            n, wait = _wait_for(s, waiting, open_counts)
            items.append({"service": s, "waiting": n, "wait": wait})
        if items:
            groups.append({"code": code, "items": items})
    return render(request, "queueapp/home.html", {
        "groups": groups,
        "onsite": _is_onsite(request),
    })


def service_detail(request, pk):
    engine.sweep()
    service = get_object_or_404(Service, pk=pk, is_active=True)
    waiting, open_counts = _queue_snapshot()
    n, wait = _wait_for(service, waiting, open_counts)
    return render(request, "queueapp/service.html", {
        "service": service,
        "docs": service.doc_list(_lang(request)),
        "waiting": n,
        "wait": wait,
        "onsite": _is_onsite(request),
    })


def book(request, pk):
    service = get_object_or_404(Service, pk=pk, is_active=True, booking_enabled=True)
    lang = _lang(request)

    if request.method == "POST":
        if _active_session_ticket(request):
            messages.warning(request, tr("already_have", lang))
            return redirect("my_ticket")
        try:
            slot = datetime.fromisoformat(request.POST.get("slot", ""))
            if timezone.is_naive(slot):
                slot = timezone.make_aware(slot)
        except ValueError:
            messages.error(request, tr("err_bad_slot", lang))
            return redirect("book", pk=pk)
        try:
            ticket = engine.create_booking(service, slot)
        except engine.QueueError as e:
            _err(request, e)
            return redirect(f"{reverse('book', args=[pk])}?day={timezone.localdate(slot).isoformat()}")
        _remember(request, ticket)
        return redirect("ticket", token=ticket.token)

    days = engine.booking_days()
    try:
        day = date.fromisoformat(request.GET.get("day", ""))
    except ValueError:
        day = None
    if day not in days:
        day = next((d for d in days if engine.slots_for(service, d)), days[0] if days else None)
    slots = engine.slots_for(service, day) if day else []
    return render(request, "queueapp/book.html", {
        "service": service,
        "days": days,
        "day": day,
        "slots": slots,
        "has_free": any(free for _s, free in slots),
    })


@require_POST
def take_live(request, pk):
    service = get_object_or_404(Service, pk=pk, is_active=True)
    lang = _lang(request)
    if not _is_onsite(request):
        messages.error(request, tr("err_not_onsite", lang))
        return redirect("service", pk=pk)
    if _active_session_ticket(request):
        messages.warning(request, tr("already_have", lang))
        return redirect("my_ticket")
    ticket = engine.create_live_ticket(service)
    _remember(request, ticket)
    return redirect("ticket", token=ticket.token)


def _ticket_state(ticket, lang):
    pos = engine.position(ticket)
    wait = engine.estimate_wait(ticket.service, pos - 1) if pos else None
    return {
        "number": ticket.number,
        "status": ticket.status,
        "status_label": tr(f"status_{ticket.status}", lang),
        "position": pos,
        "ahead": (pos - 1) if pos else None,
        "wait": wait,
        "window": ticket.window.number if ticket.window_id else None,
    }


def ticket_view(request, token):
    engine.sweep()
    ticket = get_object_or_404(Ticket.objects.select_related("service", "window"), token=token)
    lang = _lang(request)
    if ticket.is_active:
        _remember(request, ticket)
    ctx = {
        "ticket": ticket,
        "state": _ticket_state(ticket, lang),
        "docs": ticket.service.doc_list(lang),
        "qr": qr_svg(request.build_absolute_uri()),
    }
    if ticket.status == Ticket.BOOKED:
        opens, closes = engine.checkin_window(ticket)
        now = timezone.now()
        ctx.update({"checkin_open": opens <= now <= closes, "checkin_from": opens})
    return render(request, "queueapp/ticket.html", ctx)


@require_POST
def ticket_checkin(request, token):
    ticket = get_object_or_404(Ticket, token=token)
    try:
        engine.check_in(ticket)
        messages.success(request, tr("checked_in", _lang(request)))
    except engine.QueueError as e:
        _err(request, e)
    return redirect("ticket", token=token)


@require_POST
def ticket_cancel(request, token):
    ticket = get_object_or_404(Ticket, token=token)
    try:
        engine.cancel(ticket)
        messages.success(request, tr("cancelled_ok", _lang(request)))
        request.session.pop("my_token", None)
    except engine.QueueError as e:
        _err(request, e)
        return redirect("ticket", token=token)
    return redirect("home")


def my_ticket(request):
    ticket = _active_session_ticket(request)
    if ticket:
        return redirect("ticket", token=ticket.token)
    request.session.pop("my_token", None)
    messages.info(request, tr("no_my_ticket", _lang(request)))
    return redirect("home")


def api_ticket(request, token):
    engine.sweep()
    ticket = get_object_or_404(Ticket.objects.select_related("service", "window"), token=token)
    return JsonResponse(_api_ticket(ticket, _lang(request)))


# ---------------------------------------------------------------------------
# JSON API для мобильного приложения. CSRF не нужен: приложение не использует
# cookie-сессию, талон адресуется случайным токеном (как ссылка /t/<token>/).
# ---------------------------------------------------------------------------

def _api_ticket(ticket, lang="ru"):
    state = _ticket_state(ticket, lang)
    state.update({
        "token": ticket.token,
        "service": ticket.service.name,
        "slot": timezone.localtime(ticket.slot_start).strftime("%d.%m %H:%M") if ticket.slot_start else "",
        "can_checkin": ticket.status == Ticket.BOOKED,
        "can_cancel": ticket.status in (Ticket.BOOKED, Ticket.WAITING),
        "notify_ahead": settings.QUEUE["NOTIFY_AHEAD"],
    })
    return state


def _api_error(code, status=400):
    return JsonResponse({"error": tr(code)}, status=status)


def api_services(request):
    engine.sweep()
    waiting, open_counts = _queue_snapshot()
    rows = []
    for s in Service.objects.filter(is_active=True):
        n, wait = _wait_for(s, waiting, open_counts)
        rows.append({
            "id": s.pk, "code": s.code, "name": s.name, "category": tr(f"cat_{s.category}"),
            "description": s.description, "docs": s.doc_list(), "result_time": s.result_time, "note": s.note,
            "online": s.online_available, "booking": s.booking_enabled, "waiting": n, "wait": wait,
        })
    return JsonResponse({"services": rows, "lk_url": settings.LK_URL})


def api_slots(request, pk):
    service = get_object_or_404(Service, pk=pk, is_active=True, booking_enabled=True)
    days = []
    for d in engine.booking_days():
        slots = [{"start": start.isoformat(), "label": timezone.localtime(start).strftime("%H:%M"), "free": free}
                 for start, free in engine.slots_for(service, d)]
        if any(x["free"] for x in slots):
            days.append({"day": d.isoformat(), "label": fmt_day(d), "slots": slots})
    return JsonResponse({"days": days})


@csrf_exempt
@require_POST
def api_take_live(request, pk):
    service = get_object_or_404(Service, pk=pk, is_active=True)
    # Живая очередь — только для тех, кто в МФЦ: код с QR-таблички на стойке.
    if not secrets.compare_digest(request.POST.get("key", ""), settings.QR_SECRET):
        return _api_error("err_not_onsite", 403)
    return JsonResponse(_api_ticket(engine.create_live_ticket(service, actor="mobile")))


@csrf_exempt
@require_POST
def api_book(request, pk):
    service = get_object_or_404(Service, pk=pk, is_active=True)
    try:
        slot = datetime.fromisoformat(request.POST.get("slot", ""))
    except ValueError:
        return _api_error("err_bad_slot")
    if timezone.is_naive(slot):
        slot = timezone.make_aware(slot)
    try:
        return JsonResponse(_api_ticket(engine.create_booking(service, slot, actor="mobile")))
    except engine.QueueError as e:
        return _api_error(e.code)


@csrf_exempt
@require_POST
def api_ticket_action(request, token, action):
    if action not in ("checkin", "cancel"):
        raise Http404
    ticket = get_object_or_404(Ticket.objects.select_related("service", "window"), token=token)
    try:
        (engine.check_in if action == "checkin" else engine.cancel)(ticket)
    except engine.QueueError as e:
        return _api_error(e.code)
    ticket.refresh_from_db()
    return JsonResponse(_api_ticket(ticket))


def go_lk(request, pk):
    """Переход в личный кабинет: считаем, сколько обращений ушло в онлайн."""
    service = get_object_or_404(Service, pk=pk)
    engine.log("lk_redirect", service=service, actor="client")
    return redirect(settings.LK_URL)


# ---------------------------------------------------------------------------
# МФЦ: QR-табличка и табло в зоне ожидания
# ---------------------------------------------------------------------------

def qr_stand(request):
    url = request.build_absolute_uri(reverse("qr_enter", args=[settings.QR_SECRET]))
    return render(request, "queueapp/qr_stand.html", {"qr": qr_svg(url), "qr_url": url})


def qr_enter(request, key):
    if key != settings.QR_SECRET:
        raise Http404
    request.session["onsite_until"] = time.time() + ONSITE_SECONDS
    messages.success(request, tr("onsite_ok", _lang(request)))
    return redirect("home")


def board(request):
    engine.sweep()
    now = timezone.now()
    called = list(
        Ticket.objects.filter(status__in=[Ticket.CALLED, Ticket.SERVING], day=timezone.localdate())
        .select_related("window").order_by("-called_at")[:8]
    )
    recent_ids = {
        e.ticket_id for e in EventLog.objects.filter(event__in=["called", "recalled"],
                                                     ts__gte=now - timedelta(seconds=30))
    }
    waiting = engine.ordered_waiting()
    return render(request, "queueapp/board.html", {
        "called": called,
        "recent_ids": recent_ids,
        "next_numbers": [t.number for t in waiting[:6]],
        "waiting_n": len(waiting),
        "qr": qr_svg(request.build_absolute_uri(reverse("qr_enter", args=[settings.QR_SECRET]))),
    })


# ---------------------------------------------------------------------------
# Сотрудники
# ---------------------------------------------------------------------------

def staff_home(request):
    user = request.user
    if not user.is_authenticated:
        return redirect("login")
    if roles.has_role(user, roles.OPERATOR) and not user.is_superuser:
        return redirect("operator_home")
    if roles.has_role(user, roles.MANAGER) and not user.is_superuser:
        return redirect("dashboard")
    if user.is_staff:
        return redirect("admin:index")
    return render(request, "queueapp/forbidden.html", status=403)


@roles.role_required(roles.OPERATOR, roles.ADMIN)
def operator_home(request):
    windows = Window.objects.prefetch_related("services").select_related("current_ticket")
    return render(request, "queueapp/operator_home.html", {"windows": windows})


@roles.role_required(roles.OPERATOR, roles.ADMIN)
def operator_window(request, pk):
    engine.sweep()
    window = get_object_or_404(Window.objects.select_related("current_ticket__service"), pk=pk)
    current = window.current_ticket if window.current_ticket and window.current_ticket.is_active else None
    window_service_ids = list(window.services.values_list("id", flat=True))
    queue = engine.ordered_waiting(window_service_ids if window.status != Window.STATUS_CLOSED else None)
    today_events = EventLog.objects.filter(window=window, ts__date=timezone.localdate()).select_related("ticket")[:12]
    return render(request, "queueapp/operator_window.html", {
        "window": window,
        "current": current,
        "services": Service.objects.filter(is_active=True),
        "window_service_ids": window_service_ids,
        "queue": queue,
        "events": today_events,
        "done_today": Ticket.objects.filter(window=window, status=Ticket.COMPLETED,
                                            day=timezone.localdate()).count(),
    })


@require_POST
@roles.role_required(roles.OPERATOR, roles.ADMIN)
def operator_action(request, pk):
    window = get_object_or_404(Window, pk=pk)
    action = request.POST.get("action")
    actor = request.user.get_username()
    lang = _lang(request)
    try:
        if action == "open":
            ids = [int(i) for i in request.POST.getlist("services") if i.isdigit()]
            engine.open_window(window, ids, actor)
        elif action == "call_next":
            if engine.call_next(window, actor) is None:
                messages.info(request, tr("err_queue_empty", lang))
        elif action == "start":
            engine.start_serving(window, actor)
        elif action == "complete":
            engine.complete(window, actor)
        elif action == "recall":
            engine.recall(window, actor)
        elif action == "no_show":
            engine.mark_no_show(window, actor)
        elif action == "return":
            engine.return_to_queue(window, actor)
        elif action == "redirect":
            engine.redirect(window, get_object_or_404(Service, pk=request.POST.get("service")), actor)
        elif action == "walkin":
            engine.add_walkin(window, get_object_or_404(Service, pk=request.POST.get("service")), actor)
        elif action == "issue":
            note = request.POST.get("note", "").strip()
            if not note:
                raise engine.QueueError("err_note_empty")
            engine.report_issue(window, note, actor)
            messages.success(request, "Записано в журнал событий.")
        elif action == "close_soft":
            engine.close_window(window, False, actor)
        elif action == "close_now":
            engine.close_window(window, True, actor)
    except engine.QueueError as e:
        _err(request, e)
    return redirect("operator_window", pk=pk)


@roles.role_required(roles.OPERATOR, roles.ADMIN)
def api_queue(request):
    window = Window.objects.filter(pk=request.GET.get("window")).first()
    ids = list(window.services.values_list("id", flat=True)) if window and window.status != Window.STATUS_CLOSED else None
    rows = []
    now = timezone.now()
    for t in engine.ordered_waiting(ids):
        entered = t.entered_queue_at or t.created_at
        rows.append({
            "number": t.number,
            "service": t.service.name,
            "source": tr(f"source_{t.source}"),
            "since": timezone.localtime(entered).strftime("%H:%M"),
            "waited": int((now - entered).total_seconds() // 60),
            "slot": timezone.localtime(t.slot_start).strftime("%H:%M") if t.slot_start else "",
        })
    return JsonResponse({"rows": rows})


@roles.role_required(roles.MANAGER, roles.ADMIN)
def dashboard(request):
    engine.sweep()
    try:
        days = int(request.GET.get("days", 1))
    except ValueError:
        days = 1
    days = days if days in (1, 7, 28) else 1
    return render(request, "queueapp/dashboard.html", {
        "stats": analytics.build(days),
        "live_queue": engine.ordered_waiting()[:15],
    })


@roles.role_required(roles.MANAGER, roles.ADMIN)
def export_csv(request):
    try:
        days = int(request.GET.get("days", 28))
    except ValueError:
        days = 28
    start, rows = analytics.export_rows(days)
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="mfc_queue_{start}_{timezone.localdate()}.csv"'
    response.write("\ufeff")  # чтобы Excel открыл кириллицу
    csv.writer(response, delimiter=";").writerows(rows)
    return response


# ---------------------------------------------------------------------------
# Язык, доступность, проверка состояния
# ---------------------------------------------------------------------------

def _back(request):
    nxt = request.META.get("HTTP_REFERER", "")
    if nxt and url_has_allowed_host_and_scheme(nxt, allowed_hosts={request.get_host()}):
        return redirect(nxt)
    return redirect("home")


def set_lang(request, code):
    if code in LANGS:
        request.session["lang"] = code
    return _back(request)


def toggle_a11y(request):
    request.session["a11y"] = not request.session.get("a11y", False)
    return _back(request)


def health(request):
    try:
        with connection.cursor() as c:
            c.execute("SELECT 1")
        db = "ok"
    except Exception:  # noqa: BLE001
        db = "error"
    return JsonResponse({"status": "ok" if db == "ok" else "degraded", "db": db,
                         "time": timezone.now().isoformat()}, status=200 if db == "ok" else 503)
