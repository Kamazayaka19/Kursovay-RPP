"""
Самопроверка мобильного клиента против настоящего сервера на временной базе.

    python mobile/test_api.py
"""
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).parent))
from api import Api, ApiError  # noqa: E402

PORT = "8765"
env = dict(os.environ, DJANGO_DB_PATH=os.path.join(tempfile.mkdtemp(), "test.sqlite3"))
manage = [sys.executable, str(ROOT / "manage.py")]
subprocess.run(manage + ["migrate", "-v", "0"], env=env, check=True)
subprocess.run(manage + ["seed_demo"], env=env, check=True, capture_output=True)
server = subprocess.Popen(manage + ["runserver", PORT, "--noreload"], env=env,
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
try:
    api = Api(f"http://127.0.0.1:{PORT}")
    for _ in range(50):
        try:
            data = api.services()
            break
        except ApiError:
            time.sleep(0.2)
    svc = next(s for s in data["services"] if s["booking"])
    assert data["lk_url"].startswith("http") and svc["wait"] is None  # окна закрыты

    try:
        api.take_live(svc["id"], "wrong-key")
        raise AssertionError("живая очередь без кода со стойки")
    except ApiError as e:
        assert "QR" in str(e), e

    t = api.take_live(svc["id"], "mfc-stand-demo")
    assert t["status"] == "waiting" and t["ahead"] == 0 and t["can_cancel"], t
    assert api.ticket(t["token"])["number"] == t["number"]
    assert api.cancel(t["token"])["status"] == "cancelled"
    try:
        api.cancel(t["token"])
        raise AssertionError("повторная отмена")
    except ApiError:
        pass

    days = api.slots(svc["id"])
    if days:  # вечером/в выходной слотов может не быть
        slot = next(x for x in days[0]["slots"] if x["free"])
        b = api.book(svc["id"], slot["start"])
        assert b["status"] == "booked" and b["can_checkin"] and b["slot"], b
        try:
            api.checkin(b["token"])  # до слота больше 30 минут — сервер не пустит; если меньше — пройдёт
        except ApiError as e:
            assert "рано" in str(e), e

    try:
        Api("http://127.0.0.1:1").services()
        raise AssertionError("должна быть ошибка связи")
    except ApiError as e:
        assert "Нет связи" in str(e)
    print("mobile api: ok")
finally:
    server.terminate()
