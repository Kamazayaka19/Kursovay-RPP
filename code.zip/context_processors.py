from django.conf import settings
from django.contrib.staticfiles import finders
from django.templatetags.static import static

from . import roles

_logo_cache = {}


def _logo_url():
    """Логотип вуза, если файл положили в static/queueapp/. Проверяем один раз за запуск."""
    if "url" not in _logo_cache:
        url = None
        for path in getattr(settings, "MFC_LOGO_CANDIDATES", []):
            if finders.find(path):
                url = static(path)
                break
        _logo_cache["url"] = url
    return _logo_cache["url"]


def mfc(request):
    lang = request.session.get("lang", "ru")
    user = request.user
    match = getattr(request, "resolver_match", None)
    return {
        "lang": lang,
        "a11y": bool(request.session.get("a11y")),
        "has_ticket": bool(request.session.get("my_token")),
        "is_operator": roles.has_role(user, roles.OPERATOR, roles.ADMIN),
        "is_manager": roles.has_role(user, roles.MANAGER, roles.ADMIN),
        "is_mfc_admin": user.is_authenticated and user.is_staff,
        "queue_cfg": settings.QUEUE,
        "contacts": settings.MFC_CONTACTS,
        "lk_url": settings.LK_URL,
        "logo_url": _logo_url(),
        "url_name": match.url_name if match else "",
    }
