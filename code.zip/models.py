"""
Модель данных. Персональные данные НЕ собираются: талон — это номер,
услуга, время и случайный токен (решение по итогам ПР №3, сторона №13).
"""
import uuid

from django.db import models
from django.utils import timezone


def new_token():
    return uuid.uuid4().hex


class Service(models.Model):
    """Справочник услуг МФЦ: регламент, документы, канал ЛК."""

    CATEGORY_CHOICES = [
        ("certs", "Справки"),
        ("apps", "Заявления"),
        ("orders", "Выписки из приказов"),
        ("pickup", "Выдача готовых документов"),
        ("staff", "Для преподавателей и сотрудников"),
        ("other", "Другое"),
    ]

    code = models.CharField("Буква талона", max_length=2, unique=True,
                            help_text="Латинская буква: с неё начинается номер талона (A-001)")
    name = models.CharField("Название", max_length=200)
    name_en = models.CharField("Название (EN)", max_length=200, blank=True)
    category = models.CharField("Раздел", max_length=20, choices=CATEGORY_CHOICES, default="certs")
    description = models.TextField("Кратко об услуге", blank=True)
    description_en = models.TextField("Кратко об услуге (EN)", blank=True)
    documents = models.TextField("Что взять с собой", blank=True,
                                 help_text="По одному документу в строке")
    documents_en = models.TextField("Что взять с собой (EN)", blank=True)
    result_time = models.CharField("Срок готовности", max_length=120, blank=True)
    result_time_en = models.CharField("Срок готовности (EN)", max_length=120, blank=True)
    note = models.CharField("Важно знать", max_length=250, blank=True, default="",
                            help_text="Например: максимум 3 справки за один заказ")
    note_en = models.CharField("Важно знать (EN)", max_length=250, blank=True, default="")
    avg_time_min = models.PositiveSmallIntegerField("Среднее время приёма, мин", default=5)
    online_available = models.BooleanField(
        "Можно заказать в личном кабинете", default=False,
        help_text="Покажем студенту ссылку на ЛК до того, как он встанет в очередь",
    )
    booking_enabled = models.BooleanField("Запись на время", default=True)
    slot_capacity = models.PositiveSmallIntegerField("Мест в одном слоте", default=2)
    is_active = models.BooleanField("Показывать", default=True)
    order = models.PositiveSmallIntegerField("Порядок", default=100)

    class Meta:
        ordering = ["order", "name"]
        verbose_name = "услуга"
        verbose_name_plural = "справочник услуг"

    def __str__(self):
        return f"{self.code} — {self.name}"

    def doc_list(self, lang="ru"):
        text = self.documents_en if lang == "en" and self.documents_en.strip() else self.documents
        return [line.strip(" -•\t") for line in text.splitlines() if line.strip(" -•\t")]


class Window(models.Model):
    STATUS_CLOSED = "closed"
    STATUS_OPEN = "open"
    STATUS_CLOSING = "closing"
    STATUS_CHOICES = [
        (STATUS_CLOSED, "Закрыто"),
        (STATUS_OPEN, "Открыто"),
        (STATUS_CLOSING, "Закрывается"),
    ]

    number = models.PositiveSmallIntegerField("Номер окна", unique=True)
    status = models.CharField("Статус", max_length=10, choices=STATUS_CHOICES, default=STATUS_CLOSED)
    services = models.ManyToManyField(Service, verbose_name="Услуги окна", blank=True)
    current_ticket = models.OneToOneField(
        "Ticket", verbose_name="Текущий талон", null=True, blank=True,
        on_delete=models.SET_NULL, related_name="+",
    )

    class Meta:
        ordering = ["number"]
        verbose_name = "окно"
        verbose_name_plural = "окна приёма"

    def __str__(self):
        return f"Окно {self.number}"


class Ticket(models.Model):
    BOOKED = "booked"
    WAITING = "waiting"
    CALLED = "called"
    SERVING = "serving"
    COMPLETED = "completed"
    NO_SHOW = "no_show"
    CANCELLED = "cancelled"
    STATUS_CHOICES = [
        (BOOKED, "Записан на время"),
        (WAITING, "В очереди"),
        (CALLED, "Вызван"),
        (SERVING, "Обслуживается"),
        (COMPLETED, "Обслужен"),
        (NO_SHOW, "Не явился"),
        (CANCELLED, "Отменён"),
    ]
    ACTIVE = (BOOKED, WAITING, CALLED, SERVING)

    SOURCE_CHOICES = [
        ("booking", "Запись на время"),
        ("qr", "QR в МФЦ"),
        ("walkin", "Добавлен оператором"),
    ]

    number = models.CharField("Номер", max_length=10)
    day = models.DateField("День")
    service = models.ForeignKey(Service, verbose_name="Услуга", on_delete=models.PROTECT)
    source = models.CharField("Канал", max_length=10, choices=SOURCE_CHOICES)
    status = models.CharField("Статус", max_length=10, choices=STATUS_CHOICES, db_index=True)
    slot_start = models.DateTimeField("Слот записи", null=True, blank=True)
    created_at = models.DateTimeField("Создан", default=timezone.now)
    entered_queue_at = models.DateTimeField("Встал в очередь", null=True, blank=True)
    called_at = models.DateTimeField("Вызван", null=True, blank=True)
    serving_at = models.DateTimeField("Начало приёма", null=True, blank=True)
    completed_at = models.DateTimeField("Завершён", null=True, blank=True)
    window = models.ForeignKey(Window, verbose_name="Окно", null=True, blank=True,
                               on_delete=models.SET_NULL, related_name="tickets")
    redirect_count = models.PositiveSmallIntegerField("Перенаправлений", default=0)
    token = models.CharField("Токен", max_length=32, unique=True, default=new_token, editable=False)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["day", "status"])]
        verbose_name = "талон"
        verbose_name_plural = "талоны"

    def __str__(self):
        return self.number

    @property
    def is_active(self):
        return self.status in self.ACTIVE


class EventLog(models.Model):
    """Журнал событий без персональных данных."""

    ts = models.DateTimeField("Время", default=timezone.now, db_index=True)
    event = models.CharField("Событие", max_length=40)
    ticket = models.ForeignKey(Ticket, null=True, blank=True, on_delete=models.SET_NULL, verbose_name="Талон")
    window = models.ForeignKey(Window, null=True, blank=True, on_delete=models.SET_NULL, verbose_name="Окно")
    service = models.ForeignKey(Service, null=True, blank=True, on_delete=models.SET_NULL, verbose_name="Услуга")
    payload = models.CharField("Детали", max_length=300, blank=True)
    actor = models.CharField("Кто", max_length=60, blank=True)

    class Meta:
        ordering = ["-ts"]
        verbose_name = "событие"
        verbose_name_plural = "журнал событий"

    def __str__(self):
        return f"{self.ts:%d.%m %H:%M} {self.event}"
